<?php

return [

    'id' => '10',
    'name' => '迅睿CMS开源框架',
    'version' => '4.5.4',
    'updatetime' => '2021-12-24',
    'downtime' => '2022-02-23 15:54:41',

];
