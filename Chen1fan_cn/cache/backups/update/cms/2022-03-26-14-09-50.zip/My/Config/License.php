<?php
// 此文件是安装授权文件，每次下载安装包会自动生成，请勿修改
return [

    'license' => '5B2CBB14CB5BFE9CB36546F710D0E660930',
    'name' => '迅睿CMS建站框架',
    'url' => 'http://www.xunruicms.com',

];
