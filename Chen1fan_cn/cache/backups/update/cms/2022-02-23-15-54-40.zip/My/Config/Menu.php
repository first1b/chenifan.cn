<?php

/**
 * 菜单配置
 */

return [];