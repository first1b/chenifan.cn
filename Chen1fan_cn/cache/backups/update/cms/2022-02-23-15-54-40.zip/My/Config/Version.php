<?php

return [

    'id' => '10',
    'name' => '迅睿CMS开源框架',
    'version' => '4.5.2',
    'updatetime' => '2021-10-12',
    'downtime' => '2021-10-12 05:41:30',

];
