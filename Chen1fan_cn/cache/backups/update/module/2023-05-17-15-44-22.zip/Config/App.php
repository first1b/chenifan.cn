<?php

return [

    'type' => 'app',
    'name' => '内容系统',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-th-large',

];