<?php

return [

    'id' => '928',
    'version' => '2.3',
    'license' => '',
    'updatetime' => '2022-11-04 13:09:28',
    'downtime' => '2022-12-04 17:31:03',

];
