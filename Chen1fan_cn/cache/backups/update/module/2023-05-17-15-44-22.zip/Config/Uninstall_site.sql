DROP TABLE IF EXISTS `{dbprefix}share_index`;
DROP TABLE IF EXISTS `{dbprefix}share_category`;