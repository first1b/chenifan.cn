<?php

return [

    'type' => 'module',
    'name' => '{name}',
    'icon' => '{icon}',
    'system' => '1',

];