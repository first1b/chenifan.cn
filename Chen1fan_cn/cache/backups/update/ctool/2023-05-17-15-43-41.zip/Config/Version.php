<?php

return [

    'id' => '782',
    'version' => '1.10',
    'license' => '',
    'updatetime' => '2022-07-25 17:28:54',
    'downtime' => '2022-12-04 17:30:49',

];
