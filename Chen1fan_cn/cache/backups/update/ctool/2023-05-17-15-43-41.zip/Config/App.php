<?php

return [

    'type' => 'app',
    'name' => '内容维护工具',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-database',
    'uri' => 'ctool/module_content/index'

];