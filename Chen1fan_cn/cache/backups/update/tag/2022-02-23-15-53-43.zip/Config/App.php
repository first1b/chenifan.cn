<?php

return [

    'type' => 'app',
    'name' => 'TAG关键词库',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-tags',

];