<?php namespace Phpcmf\Controllers;

class Home extends \Phpcmf\Common
{

    public function index()
    {

        // 获取tag数据
        $tag = dr_safe_replace(urldecode(\Phpcmf\Service::L('Input')->get('name')));
        if (!$tag) {
            exit($this->goto_404_page(dr_lang('Tag参数不存在')));
        }

        $name = 'tag_'.SITE_ID.'-'.$tag;
        list($data, $parent, $related) = \Phpcmf\Service::L('cache')->get_data($name);
        if (!$data) {
            $rule = \Phpcmf\Service::L('cache')->get('urlrule', SITE_REWRITE, 'value');
            $join = $rule['catjoin'] ? $rule['catjoin'] : '/';
            $tag = @end(@explode($join, $tag)); // 转换tag值

            $data = \Phpcmf\Service::M('Tag', 'tag')->tag_row($tag);
            // 格式化显示
            $field = \Phpcmf\Service::L('cache')->get('tag-'.SITE_ID.'-field');
            $field['content'] = [
                'ismain' => 1,
                'name' => dr_lang('描述信息'),
                'fieldname' => 'content',
                'fieldtype' => 'Ueditor',
                'setting' => array(
                    'option' => array(
                        'mode' => 1,
                        'height' => 300,
                        'width' => '100%',
                    ),
                )
            ];
            $data = \Phpcmf\Service::L('Field')->format_value($field, $data);
            $parent = $related = [];

            // 合并缓存数据
            $data['tags'] = [ $data['name'] ];

            // 是否存在子tag
            $result2 = \Phpcmf\Service::M()->table(SITE_ID.'_tag')->where('pid', $data['id'])->order_by('displayorder DESC,id ASC')->getAll();
            if ($result2) {
                $parent = [];
                foreach ($result2 as $t) {
                    $t['url'] = isset($t['myurl']) && $t['myurl'] ? $t['myurl'] : \Phpcmf\Service::L('router')->tag_url($t['pcode']);
                    $related[] = $t;
                    $data['tags'][] = $t['name'];
                }
            } elseif ($data['pid']) {
                // 本身就是子词
                $parent = \Phpcmf\Service::M()->table(SITE_ID.'_tag')->get($data['pid']);
                $parent['url'] = isset($parent['myurl']) && $parent['myurl'] ? $parent['myurl'] : \Phpcmf\Service::L('router')->tag_url($parent['pcode']);
                $result2 = \Phpcmf\Service::M()->table(SITE_ID.'_tag')->where('pid', $data['pid'])->order_by('displayorder DESC,id ASC')->getAll();
                foreach ($result2 as $t) {
                    $t['url'] = isset($t['myurl']) && $t['myurl'] ? $t['myurl'] : \Phpcmf\Service::L('router')->tag_url($t['pcode']);
                    $related[] = $t;
                    $data['tags'][] = $t['name'];
                }
            }
            $data['tags'] = implode(',', $data['tags']);
            SYS_CACHE && \Phpcmf\Service::L('cache')->set_data($name, [$data, $parent, $related], SYS_CACHE_SHOW * 3600);
        }

        if (!$data) {
            exit($this->goto_404_page(dr_lang('此标签[%s]不存在', $tag)));
        }
        //!$data && $data = ['code' => $tag, 'name' => $tag, 'tags' => $tag];

        \Phpcmf\Service::V()->assign(array(
            'tag' => $data,
            'parent' => $parent,
            'related' => $related,
            'meta_title' => $data['name'].SITE_SEOJOIN.SITE_NAME,
            'meta_keywords' => $this->get_cache('site', SITE_ID, 'seo', 'SITE_KEYWORDS'),
            'meta_description' => $this->get_cache('site', SITE_ID, 'seo', 'SITE_DESCRIPTION')
        ));
        \Phpcmf\Service::V()->display('tag.html');
    }

}
