<?php

return [

    'id' => '402',
    'version' => '7.38',
    'license' => 'dev',
    'updatetime' => '2022-03-09',
    'downtime' => '2022-03-25',

];
