<?php

return [

    'type' => 'app',
    'name' => '字段标签调用工具',
    'author' => '小波设计',
    'icon' => 'fa fa-tag',

];