联动菜单名称：{dr_linkage('$linkname', $value, 0, 'name')}
联动菜单顶级的名称：{dr_linkage('$linkname', $value, 1, 'name')}
面包屑导航：{dr_linkagepos('$linkname', $value, ' - ')}