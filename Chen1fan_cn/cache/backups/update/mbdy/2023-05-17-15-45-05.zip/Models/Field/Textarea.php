普通输出：{$value}
截取10个字输出：{dr_strcut($value, 10, '...')}
换行显示：{nl2br($value)}
按HTML模式显示：{dr_code2html($value)}