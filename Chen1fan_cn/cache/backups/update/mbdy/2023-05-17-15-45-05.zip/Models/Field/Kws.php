{php $kws = dr_get_content_kws($value, 'MOD_DIR');}
<br>
{loop $kws $name8 $url8}
{$url8}
{$name8}
{/loop}