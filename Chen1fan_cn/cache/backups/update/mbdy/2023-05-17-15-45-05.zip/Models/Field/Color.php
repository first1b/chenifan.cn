颜色编码输出：{$value}
当存在颜色才输出：{if $value}{$value}{/if}