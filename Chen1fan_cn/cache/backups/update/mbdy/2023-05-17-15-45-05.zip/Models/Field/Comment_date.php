自定义时间：{dr_date($time, 'Y-m-d')}
友好的时间：{dr_fdate($time)}