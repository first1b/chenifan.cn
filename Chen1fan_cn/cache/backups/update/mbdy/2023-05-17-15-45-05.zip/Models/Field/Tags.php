{php $tags = dr_get_content_tags($value);}
<br>
{loop $tags $name8 $url8}
{$url8}
{$name8}
{/loop}