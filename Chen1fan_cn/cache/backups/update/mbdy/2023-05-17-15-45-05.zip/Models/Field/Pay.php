普通输出：{$value}
价格值：{dr_price_value($value)}