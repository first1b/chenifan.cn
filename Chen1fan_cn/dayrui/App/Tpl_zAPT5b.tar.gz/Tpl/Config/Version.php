<?php

return [

    'id' => '1000',
    'version' => '1.1',
    'license' => '',
    'updatetime' => '2022-06-10 11:36:46',
    'downtime' => '2022-12-04 17:09:19',

];
