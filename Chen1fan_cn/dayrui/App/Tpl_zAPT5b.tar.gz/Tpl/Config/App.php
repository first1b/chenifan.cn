<?php

return [

    'type' => 'app',
    'name' => '模板界面管理',
    'author' => '迅睿云软件',
    'icon' => 'fa fa-html5',

];