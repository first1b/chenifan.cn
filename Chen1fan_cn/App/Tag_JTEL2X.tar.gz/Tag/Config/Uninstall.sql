DROP TABLE IF EXISTS `{dbprefix}xxxx`;

