<?php

return [

    'id' => '364',
    'version' => '2.6',
    'license' => '340B706FB4F5035F33FCFA07FBBAF47689',
    'updatetime' => '2021-01-18',
    'downtime' => '2021-02-01',

];
