<?php

\Phpcmf\Hooks::on('module_content_after', function($data, $old) {
    // 内容发布或者修改之后
    $config = \Phpcmf\Service::M('app')->get_config('tag');
    if ($data[1]['status'] == 9 && $config['auto_save']) {
        // 9表示审核通过的
        // 自动存储tag
        \Phpcmf\Service::M('tag', 'tag')->auto_save_tag($data);
    }
});