<?php namespace Phpcmf\Model\Tag;

// tag模型类

class Tag extends \Phpcmf\Model
{

    protected $tablename;
    protected $link_cache;


    public function __construct(...$params)
    {
        parent::__construct(...$params);
        $this->tablename = SITE_ID.'_tag';
        $this->link_cache = WRITEPATH.'tags/';
    }

    // 通过关键字获取tag
    public function tag_row($code) {

        // 首先查询
        $data = $this->db->table($this->tablename)->where('code', $code)->get()->getRowArray();
        $data && $this->db->table($this->tablename)->where('id', (int)$data['id'])->set('hits', intval($data['hits'])+1)->update();

        return $data;
    }

    // 检查别名是否可用
    public function check_code($id, $value) {

        if (!$value) {
            return 1;
        }

        return $this->table($this->tablename)->is_exists($id, 'code', $value);
    }

    // 检查名称是否可用
    public function check_name($id, $value) {

        if (!$value) {
            return 1;
        }

        return $this->table($this->tablename)->is_exists($id, 'name', $value);
    }

    // 批量
    public function save_all_data($pid, $data) {

        $c = 0;
        $py = \Phpcmf\Service::L('pinyin'); // 拼音转换类
        $names = explode(PHP_EOL, trim($data));
        foreach ($names as $t) {
            $t = trim($t);
            if (!$t) {
                continue;
            } elseif ($this->check_name(0, $t)) {
                return dr_return_data(0, dr_lang('tag【%s】已经存在', $t));
            }
            $cname = $py->result($t);
            $count = $this->db->table($this->tablename)->where('code', $cname)->countAllResults();
            $code = $count ? $cname.$count : $cname;
            $pcode = $this->get_pcode(['pid' => $pid, 'code' => $code]);
            if ($pid) {
                // 标记存在子菜单
                $this->table($this->tablename)->update($pid, array(
                    'childids' => 1,
                ));
            }
            $rt = $this->table($this->tablename)->insert(array(
                'pid' => $pid,
                'name' => $t,
                'code' => $code,
                'pcode' => $pcode,
                'hits' => 0,
                'displayorder' => 0,
                'childids' => '',
                'content' => '',
            ));
            if (!$rt['code']) {
                return $rt;
            }
            $c++;
        }
        return dr_return_data(1, dr_lang('批量添加%s个', $c));
    }

    // save
    public function save_data($id, $data) {
        $this->table($this->tablename)->update($id, $data);
    }


    // 获取pcode
    public function get_pcode($data) {

        if (!$data['pid']) {
            return $data['code'];
        }

        $row = $this->table($this->tablename)->get($data['pid']);

        return trim($row['code'].'/'.$data['code'], '/');
    }


    // 存储到tag
    public function auto_save_tag($data) {

        $tag = $data[1]['keywords'];
        if (!$tag) {
            return;
        }

        if (!dr_is_app('tag')) {
            return;
        }

        $arr = explode(',', $tag);
        foreach ($arr as $t) {
            if ($t) {
                if ($this->table($this->tablename)->is_exists(0, 'name', $t)) {
                    // 已经存在
                    continue;
                }
                $cname = \Phpcmf\Service::L('pinyin')->result($t); // 拼音转换类
                $count = $this->db->table($this->tablename)->where('code', $cname)->countAllResults();
                $code = $count ? $cname.$count : $cname;
                $pcode = $this->_get_tag_pcode(['pid' => 0, 'code' => $code]);
                $this->table($this->tablename)->insert(array(
                    'pid' => 0,
                    'name' => $t,
                    'code' => $code,
                    'pcode' => $pcode,
                    'hits' => 0,
                    'displayorder' => 0,
                    'childids' => '',
                    'content' => '',
                ));
            }
        }
    }

    // 获取pcode
    private function _get_tag_pcode($data) {

        if (!$data['pid']) {
            return $data['code'];
        }

        $row = $this->table($this->tablename)->get($data['pid']);

        return trim($row['code'].'/'.$data['code'], '/');
    }

    // 缓存链接，用于内链
    private function _save_tag_cache($siteid, $name, $url) {
        $file = md5($siteid.'-'.$name);
        file_put_contents($this->link_cache.$file, $url);
    }

    // 提取关键词
    public function get_keywords($kw) {

        $rt = [];
        $tags = \Phpcmf\Service::L('cache')->get('tag-' . SITE_ID);
        if ($tags) {
            foreach ($tags as $t => $url) {
                if (strpos($kw, $t) !== false) {
                    $rt[] = $t; // 找到了
                }
            }
        }

        return $rt;
    }

    // 内链
    public function neilian($content, $blank = 1, $num = 1) {

        $tags = \Phpcmf\Service::L('cache')->get('tag-'.SITE_ID);
        if ($tags) {
            return dr_content_link($tags, $content, $num, $blank);
        }

        return $content;
    }

    // 缓存
    public function cache($siteid = SITE_ID) {

        if ($siteid == 1) {
            dr_dir_delete($this->link_cache);
        }

        if (!is_dir($this->link_cache)) {
            dr_mkdirs($this->link_cache);
        }

        $cache = [];

        $result = $this->table($siteid.'_tag')->order_by('displayorder DESC,id ASC')->getAll();
        if ($result) {
            foreach ($result as $data) {
                // 缓存链接，用于内链
                $url = isset($data['myurl']) && $data['myurl'] ? $data['myurl'] : \Phpcmf\Service::L('router')->tag_url($data['pcode']);
                $this->_save_tag_cache($siteid, $data['name'], $url);
                // 缓存名称
                $cache[$data['name']] = $url;
            }
        }

        /*
        $result = $this->table($siteid.'_tag')->where('pid', 0)->order_by('displayorder DESC,id ASC')->getAll(10000);
        if ($result) {
            foreach ($result as $data) {
                $tag = $data['name'];
                $result2 = $ids = $code = [];
                if ($data['childids']) {
                    // 子级缓存
                    $result2 = $this->table($siteid.'_tag')->where('pid', $data['id'])->order_by('displayorder DESC,id ASC')->getAll(1000);
                    if ($result2) {
                        foreach ($result2 as $data2) {
                            $tag.= ','.$data2['name'];
                            $ids[] = $data2['id'];
                            $code[] = $data2['code'];
                            $url = isset($data2['myurl']) && $data2['myurl'] ? $data2['myurl'] : \Phpcmf\Service::L('router')->tag_url($data2['pcode']);
                            $cache[$data2['code']] = [
                                'id' => $data2['id'],
                                'pid' => $data['code'],
                                'name' => $data2['name'],
                                'codes' => '',
                                'tags' => $data2['name'],
                                'total' => 0,
                                'childids' => [$data2['id']],
                                'url' => $url,
                            ];
                            $this->_save_tag_cache($siteid, $data2['name'], $url);
                        }
                    }
                }
                // 本级缓存
                $url = isset($data['myurl']) && $data['myurl'] ? $data['myurl'] : \Phpcmf\Service::L('router')->tag_url($data['pcode']);
                $this->_save_tag_cache($siteid, $data['name'], $url);
                $cache[$data['code']] = [
                    'id' => $data['id'],
                    'pid' => '',
                    'name' => $data['name'],
                    'tags' => trim($tag, ','),
                    'codes' => $code,
                    'total' => dr_count($result2),
                    'childids' => $ids,
                    'url' => $url,
                ];
            }
        }*/


        // 自定义字段
        $cache2 = [];
        $field = $this->db->table('field')->where('disabled', 0)->where('relatedid', $siteid)->where('relatedname', 'tag')->orderBy('displayorder ASC,id ASC')->get()->getResultArray();
        if ($field) {
            foreach ($field as $f) {
                $f['setting'] = dr_string2array($f['setting']);
                $cache2[$f['fieldname']] = $f;
            }
        }

        \Phpcmf\Service::L('cache')->set_file('tag-'.$siteid.'-field', $cache2);
        \Phpcmf\Service::L('cache')->set_file('tag-'.$siteid, $cache);

        return $cache;
    }
}