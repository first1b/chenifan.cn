<?php namespace Phpcmf\Controllers;

class Home extends \Phpcmf\Common
{
    protected $total_total;  //总数
    protected $totala;       //提醒
    protected $txa;       //求车牌号注意事项
    protected $txb;       //京牌转让注意事项
    protected $txc;       //买车用车卖车提醒
    protected $totalb;       //指南
    protected $zna;       //北京车牌办理指南
    protected $znb;       //北京车牌转让技巧
    protected $znc;       //买车用车卖车技巧
    protected $totalc;       //求车牌
    protected $qpa;       //小汽车指标出租
    protected $qpb;       //新能源车牌出租
    protected $qpc;       //北京车牌出售
    protected $qpd;       //靓号车牌转让
    protected $totald;       //转让
    protected $zra;       //求租北京车牌
    protected $zrb;       //求租新能源车牌
    protected $zrc;       //求购京牌指标
    protected $zrd;       //求北京车牌靓号
    protected $totale;       //问答
    protected $wda;       //求车牌号常见问答
    protected $wdb;       //京牌转让常见问题
    protected $wdc;       //买车用车卖车答疑
    protected $totalf;       //资讯
    protected $zxa;       //车牌指标
    protected $zxb;       //汽车资讯
    protected $zxc;       //杂谈热点
    protected $table;        //表名
    protected $order;        //排序
    protected $cachenum;        //分页数量

    public function __construct(...$params) {
        parent::__construct(...$params);


        $this->table = SITE_ID.'_tag'; //表名
        $this->order = 'displayorder desc,id asc'; //排序
        $this->cachenum = \Phpcmf\Service::M('app')->get_config(APP_DIR); //获取 cache/app/tag.cache 下保存的分页内容数量



        //获取类型
        $types = \Phpcmf\Service::L('input')->get('type');
        if($types==''){
            $this->total_total = \Phpcmf\Service::M()->table($this->table)->where(" zongs > 0 ")->counts();
        }elseif($types=='1'){
            $this->total_total = \Phpcmf\Service::M()->table($this->table)->where(" titnum > 0 ")->counts();
        }elseif($types=='2'){
            $this->total_total = \Phpcmf\Service::M()->table($this->table)->where(" gjzzs > 0 ")->counts();
        }elseif($types=='3'){
            $this->total_total = \Phpcmf\Service::M()->table($this->table)->where(" nrzs > 0 ")->counts();
        }

        //提醒
        if($types==''){
            $this->totala = \Phpcmf\Service::M()->table($this->table)->where(" txzcs > 0 ")->counts();
        }elseif($types=='1'){
            $this->totala = \Phpcmf\Service::M()->table($this->table)->where(" txbtcs > 0 ")->counts();
        }elseif($types=='2'){
            $this->totala = \Phpcmf\Service::M()->table($this->table)->where(" txgjccs > 0 ")->counts();
        }elseif($types=='3'){
            $this->totala = \Phpcmf\Service::M()->table($this->table)->where(" txnrcs > 0 ")->counts();
        }
        //求车牌号注意事项
        if($types==''){
            $this->txa = \Phpcmf\Service::M()->table($this->table)->where(" qpzyzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->txa = \Phpcmf\Service::M()->table($this->table)->where(" qpzybt > 0 ")->counts();
        }elseif($types=='2'){
            $this->txa = \Phpcmf\Service::M()->table($this->table)->where(" qpzygjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->txa = \Phpcmf\Service::M()->table($this->table)->where(" qpzynr > 0 ")->counts();
        }
        //京牌转让注意事项
        if($types==''){
            $this->txb = \Phpcmf\Service::M()->table($this->table)->where(" zrzyzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->txb = \Phpcmf\Service::M()->table($this->table)->where(" zrzybt > 0 ")->counts();
        }elseif($types=='2'){
            $this->txb = \Phpcmf\Service::M()->table($this->table)->where(" zrzygjz > 0 ")->counts();
        }elseif($types=='3'){
            $this->txb = \Phpcmf\Service::M()->table($this->table)->where(" zrzynr > 0 ")->counts();
        }
        //买车用车卖车提醒
        if($types==''){
            $this->txc = \Phpcmf\Service::M()->table($this->table)->where(" myctxzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->txc = \Phpcmf\Service::M()->table($this->table)->where(" myctxbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->txc = \Phpcmf\Service::M()->table($this->table)->where(" myctxgjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->txc = \Phpcmf\Service::M()->table($this->table)->where(" myctxnr > 0 ")->counts();
        }

        //指南
        if($types==''){
            $this->totalb = \Phpcmf\Service::M()->table($this->table)->where(" znzcs > 0 ")->counts();
        }elseif($types=='1'){
            $this->totalb = \Phpcmf\Service::M()->table($this->table)->where(" znbtcs > 0 ")->counts();
        }elseif($types=='2'){
            $this->totalb = \Phpcmf\Service::M()->table($this->table)->where(" zngjccs > 0 ")->counts();
        }elseif($types=='3'){
            $this->totalb = \Phpcmf\Service::M()->table($this->table)->where(" znnrcs > 0 ")->counts();
        }
        //北京车牌办理指南
        if($types==''){
            $this->zna = \Phpcmf\Service::M()->table($this->table)->where(" blznzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->zna = \Phpcmf\Service::M()->table($this->table)->where(" blznbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->zna = \Phpcmf\Service::M()->table($this->table)->where(" blzngjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->zna = \Phpcmf\Service::M()->table($this->table)->where(" blznnr > 0 ")->counts();
        }
        //北京车牌转让技巧
        if($types==''){
            $this->znb = \Phpcmf\Service::M()->table($this->table)->where(" zrjqzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->znb = \Phpcmf\Service::M()->table($this->table)->where(" zrjqbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->znb = \Phpcmf\Service::M()->table($this->table)->where(" zrjqgjz > 0 ")->counts();
        }elseif($types=='3'){
            $this->znb = \Phpcmf\Service::M()->table($this->table)->where(" zrjqnr > 0 ")->counts();
        }
        //买车用车卖车技巧
        if($types==''){
            $this->znc = \Phpcmf\Service::M()->table($this->table)->where(" mcjqzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->znc = \Phpcmf\Service::M()->table($this->table)->where(" mcjqbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->znc = \Phpcmf\Service::M()->table($this->table)->where(" mcjqgjz > 0 ")->counts();
        }elseif($types=='3'){
            $this->znc = \Phpcmf\Service::M()->table($this->table)->where(" mcjqnr > 0 ")->counts();
        }

        //求车牌
        if($types==''){
            $this->totalc = \Phpcmf\Service::M()->table($this->table)->where(" qcpzcs > 0 ")->counts();
        }elseif($types=='1'){
            $this->totalc = \Phpcmf\Service::M()->table($this->table)->where(" qcpbtcs > 0 ")->counts();
        }elseif($types=='2'){
            $this->totalc = \Phpcmf\Service::M()->table($this->table)->where(" qcpgjccs > 0 ")->counts();
        }elseif($types=='3'){
            $this->totalc = \Phpcmf\Service::M()->table($this->table)->where(" qcpnrcs > 0 ")->counts();
        }
        //小汽车指标出租
        if($types==''){
            $this->qpa = \Phpcmf\Service::M()->table($this->table)->where(" zbczzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->qpa = \Phpcmf\Service::M()->table($this->table)->where(" zbczbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->qpa = \Phpcmf\Service::M()->table($this->table)->where(" zbczgjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->qpa = \Phpcmf\Service::M()->table($this->table)->where(" zbcznr > 0 ")->counts();
        }
        //新能源车牌出租
        if($types==''){
            $this->qpb = \Phpcmf\Service::M()->table($this->table)->where(" cpczzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->qpb = \Phpcmf\Service::M()->table($this->table)->where(" cpczbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->qpb = \Phpcmf\Service::M()->table($this->table)->where(" cpczgjz > 0 ")->counts();
        }elseif($types=='3'){
            $this->qpb = \Phpcmf\Service::M()->table($this->table)->where(" cpcznr > 0 ")->counts();
        }
        //北京车牌出售
        if($types==''){
            $this->qpc = \Phpcmf\Service::M()->table($this->table)->where(" cpcszs > 0 ")->counts();
        }elseif($types=='1'){
            $this->qpc = \Phpcmf\Service::M()->table($this->table)->where(" cpcsbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->qpc = \Phpcmf\Service::M()->table($this->table)->where(" cpcsgjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->qpc = \Phpcmf\Service::M()->table($this->table)->where(" cpcsnr > 0 ")->counts();
        }
        //靓号车牌转让
        if($types==''){
            $this->qpd = \Phpcmf\Service::M()->table($this->table)->where(" cpzrzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->qpd = \Phpcmf\Service::M()->table($this->table)->where(" cpzrbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->qpd = \Phpcmf\Service::M()->table($this->table)->where(" cpzrgjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->qpd = \Phpcmf\Service::M()->table($this->table)->where(" cpzrnr > 0 ")->counts();
        }

        //转让
        if($types==''){
            $this->totald = \Phpcmf\Service::M()->table($this->table)->where(" zrzcs > 0 ")->counts();
        }elseif($types=='1'){
            $this->totald = \Phpcmf\Service::M()->table($this->table)->where(" zrbtcs > 0 ")->counts();
        }elseif($types=='2'){
            $this->totald = \Phpcmf\Service::M()->table($this->table)->where(" zrgjccs > 0 ")->counts();
        }elseif($types=='3'){
            $this->totald = \Phpcmf\Service::M()->table($this->table)->where(" zrnrcs > 0 ")->counts();
        }
        //求租北京车牌
        if($types==''){
            $this->zra = \Phpcmf\Service::M()->table($this->table)->where(" qzcpzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->zra = \Phpcmf\Service::M()->table($this->table)->where(" qzcpbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->zra = \Phpcmf\Service::M()->table($this->table)->where(" qzcpgjz > 0 ")->counts();
        }elseif($types=='3'){
            $this->zra = \Phpcmf\Service::M()->table($this->table)->where(" qzcpnr > 0 ")->counts();
        }
        //求租新能源车牌
        if($types==''){
            $this->zrb = \Phpcmf\Service::M()->table($this->table)->where(" xnyzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->zrb = \Phpcmf\Service::M()->table($this->table)->where(" xnybt > 0 ")->counts();
        }elseif($types=='2'){
            $this->zrb = \Phpcmf\Service::M()->table($this->table)->where(" xnygjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->zrb = \Phpcmf\Service::M()->table($this->table)->where(" xnynr > 0 ")->counts();
        }
        //求购京牌指标
        if($types==''){
            $this->zrc = \Phpcmf\Service::M()->table($this->table)->where(" jpzbzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->zrc = \Phpcmf\Service::M()->table($this->table)->where(" jpzbbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->zrc = \Phpcmf\Service::M()->table($this->table)->where(" jpzbgjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->zrc = \Phpcmf\Service::M()->table($this->table)->where(" jpzbnr > 0 ")->counts();
        }
        //求北京车牌靓号
        if($types==''){
            $this->zrd = \Phpcmf\Service::M()->table($this->table)->where(" cpjhzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->zrd = \Phpcmf\Service::M()->table($this->table)->where(" cpjhbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->zrd = \Phpcmf\Service::M()->table($this->table)->where(" cpjhgjz > 0 ")->counts();
        }elseif($types=='3'){
            $this->zrd = \Phpcmf\Service::M()->table($this->table)->where(" cpjhnr > 0 ")->counts();
        }

        //问答
        if($types==''){
            $this->totale = \Phpcmf\Service::M()->table($this->table)->where(" wdzcs > 0 ")->counts();
        }elseif($types=='1'){
            $this->totale = \Phpcmf\Service::M()->table($this->table)->where(" wdbtcs > 0 ")->counts();
        }elseif($types=='2'){
            $this->totale = \Phpcmf\Service::M()->table($this->table)->where(" wdgjccs > 0 ")->counts();
        }elseif($types=='3'){
            $this->totale = \Phpcmf\Service::M()->table($this->table)->where(" wdnrcs > 0 ")->counts();
        }
        //求车牌号常见问答
        if($types==''){
            $this->wda = \Phpcmf\Service::M()->table($this->table)->where(" qpwdzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->wda = \Phpcmf\Service::M()->table($this->table)->where(" qpwdbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->wda = \Phpcmf\Service::M()->table($this->table)->where(" qpwdgjz > 0 ")->counts();
        }elseif($types=='3'){
            $this->wda = \Phpcmf\Service::M()->table($this->table)->where(" qpwdnr > 0 ")->counts();
        }
        //京牌转让常见问题
        if($types==''){
            $this->wdb = \Phpcmf\Service::M()->table($this->table)->where(" zrwdzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->wdb = \Phpcmf\Service::M()->table($this->table)->where(" zrwdbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->wdb = \Phpcmf\Service::M()->table($this->table)->where(" zrwdgjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->wdb = \Phpcmf\Service::M()->table($this->table)->where(" zrwdnr > 0 ")->counts();
        }
        //买车用车卖车答疑
        if($types==''){
            $this->wdc = \Phpcmf\Service::M()->table($this->table)->where(" dyzss > 0 ")->counts();
        }elseif($types=='1'){
            $this->wdc = \Phpcmf\Service::M()->table($this->table)->where(" dayibt > 0 ")->counts();
        }elseif($types=='2'){
            $this->wdc = \Phpcmf\Service::M()->table($this->table)->where(" dygjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->wdc = \Phpcmf\Service::M()->table($this->table)->where(" dayinr > 0 ")->counts();
        }

        //资讯
        if($types==''){
            $this->totalf = \Phpcmf\Service::M()->table($this->table)->where(" bdzxzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->totalf = \Phpcmf\Service::M()->table($this->table)->where(" bdzxbtcs > 0 ")->counts();
        }elseif($types=='2'){
            $this->totalf = \Phpcmf\Service::M()->table($this->table)->where(" bdgjccs > 0 ")->counts();
        }elseif($types=='3'){
            $this->totalf = \Phpcmf\Service::M()->table($this->table)->where(" bdnrcs > 0 ")->counts();
        }
        //车牌指标
        if($types==''){
            $this->zxa = \Phpcmf\Service::M()->table($this->table)->where(" cpzbzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->zxa = \Phpcmf\Service::M()->table($this->table)->where(" cpzbbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->zxa = \Phpcmf\Service::M()->table($this->table)->where(" cpzbgjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->zxa = \Phpcmf\Service::M()->table($this->table)->where(" cpzbnr > 0 ")->counts();
        }
        //汽车资讯
        if($types==''){
            $this->zxb = \Phpcmf\Service::M()->table($this->table)->where(" qczxzs > 0 ")->counts();
        }elseif($types=='1'){
            $this->zxb = \Phpcmf\Service::M()->table($this->table)->where(" qczxbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->zxb = \Phpcmf\Service::M()->table($this->table)->where(" qczxgjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->zxb = \Phpcmf\Service::M()->table($this->table)->where(" qczxnr > 0 ")->counts();
        }
        //杂谈热点
        if($types==''){
            $this->zxc = \Phpcmf\Service::M()->table($this->table)->where(" ztrd > 0 ")->counts();
        }elseif($types=='1'){
            $this->zxc = \Phpcmf\Service::M()->table($this->table)->where(" ztrdbt > 0 ")->counts();
        }elseif($types=='2'){
            $this->zxc = \Phpcmf\Service::M()->table($this->table)->where(" ztrdgjc > 0 ")->counts();
        }elseif($types=='3'){
            $this->zxc = \Phpcmf\Service::M()->table($this->table)->where(" ztrdnr > 0 ")->counts();
        }


        //
        \Phpcmf\Service::V()->assign([
            'meta_title' => 'TAGS',
        ]);
    }

    // 建立分页链接
    public function mypage($url, $total,$pagesize) {
        $config = require CMSPATH.'Config/Apage.php';
        $config['base_url'] = $url.'&page={page}';
        if ($pagesize==0)
            $config['per_page'] = SYS_ADMIN_PAGESIZE;
        else
            $config['per_page'] =$pagesize;
        $config['total_rows'] = $total;
        return \Phpcmf\Service::L('page')->initialize($config)->create_links();
    }

    public function index()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        // 获取tag数据
        $tag = dr_safe_replace(urldecode(\Phpcmf\Service::L('Input')->get('name')));

        //获取栏目类别
        $lm = \Phpcmf\Service::L('input')->get('lm');
        //内容类别
        $lb = \Phpcmf\Service::L('input')->get('lb');


        if (!$tag) {
            exit($this->goto_404_page(dr_lang('Tag参数不存在')));
        }

        $name = 'tag_'.SITE_ID.'-'.$tag;
        list($data, $parent, $related) = \Phpcmf\Service::L('cache')->get_data($name);

        if (!$data) {
            $rule = \Phpcmf\Service::L('cache')->get('urlrule', SITE_REWRITE, 'value');
            $join = $rule['catjoin'] ? $rule['catjoin'] : '/';
            $tag = @end(@explode($join, $tag)); // 转换tag值

            $data = \Phpcmf\Service::M('Tag', 'tag')->tag_row($tag);

            $jsl = unserialize($data['jsl']);
            $jsl = $jsl['1'];
            $jslrq = unserialize($data['jslrq']);
            $jslrq = $jslrq['1'];
            $this->jiansuo($jsl,$jslrq,$data['id']);

            //格式化显示
            $field = \Phpcmf\Service::L('cache')->get('tag-'.SITE_ID.'-field');
            $field['content'] = [
                'ismain' => 1,
                'name' => dr_lang('描述信息'),
                'fieldname' => 'content',
                'fieldtype' => 'Ueditor',
                'setting' => array(
                    'option' => array(
                        'mode' => 1,
                        'height' => 300,//改了这里
                        // 'height' => '100%',
                        'width' => '100%',
                    ),
                )
            ];
            $data = \Phpcmf\Service::L('Field')->format_value($field, $data);
            $parent = $related = [];

            // 合并缓存数据
            $data['tags'] = [ $data['name'] ];
            $data['tags'] = implode(',', $data['tags']);
            SYS_CACHE && \Phpcmf\Service::L('cache')->set_data($name, [$data, $parent, $related], SYS_CACHE_SHOW * 3600);
        }

        if (!$data) {
            exit($this->goto_404_page(dr_lang('此标签[%s]不存在', $tag)));
        }
        //!$data && $data = ['code' => $tag, 'name' => $tag, 'tags' => $tag];

        //tag搜索内容
        $keyword=dr_safe_replace($tag); //搜索内容
        $page=(int)\Phpcmf\Service::L('input')->get('page');  //当前页码

        //每页显示记录条数
        $limit=10;    //或者默认为系统设置的每页个数 SYS_ADMIN_PAGESIZE
        //总页数
        $total_pages=0;

        //字段
        $fieldAll = ' title,thumb,inputtime,keywords,description,url,content '; //需要查询的字段

        //类别
        if ($lb==''){
            $fieldQuery = ' (title LIKE "%'.$tag.'%" OR keywords LIKE "%'.$tag.'%" OR content LIKE "%'.$tag.'%")';  //查询所有字段
        }elseif($lb==1){
            $fieldQuery = ' (title LIKE "%'.$tag.'%")';  //查询标题字段
        }elseif($lb==2){
            $fieldQuery = ' (keywords LIKE "%'.$tag.'%")';  //查询关键词字段
        }elseif($lb==3){
            $fieldQuery = ' (content LIKE "%'.$tag.'%")';  //查询内容字段
        }

        $cun = ' count(*) AS b '; //统计字段

        //查询的表
        $tba = 'SELECT '.$fieldAll.' FROM dr_1_tix WHERE '.$fieldQuery.''; //提醒
        $tbb = 'SELECT '.$fieldAll.' FROM dr_1_zhin WHERE '.$fieldQuery.''; //指南
        $tbc = 'SELECT '.$fieldAll.' FROM dr_1_zhuanr WHERE '.$fieldQuery.''; //求车牌
        $tbd = 'SELECT '.$fieldAll.' FROM dr_1_qcp WHERE '.$fieldQuery.''; //转让
        $tbe = 'SELECT '.$fieldAll.' FROM dr_1_wend WHERE '.$fieldQuery.''; //问答
        $tbf = 'SELECT '.$fieldAll.' FROM dr_1_news WHERE '.$fieldQuery.''; //资讯


        //统计的表
        $counta = ' SELECT '.$cun.' FROM dr_1_tix WHERE '.$fieldQuery.''; //提醒
        $countb = ' SELECT '.$cun.' FROM dr_1_zhin WHERE '.$fieldQuery.''; //指南
        $countc = ' SELECT '.$cun.' FROM dr_1_zhuanr WHERE '.$fieldQuery.''; //求车牌
        $countd = ' SELECT '.$cun.' FROM dr_1_qcp WHERE '.$fieldQuery.''; //转让
        $counte = ' SELECT '.$cun.' FROM dr_1_wend WHERE '.$fieldQuery.''; //问答
        $countf = ' SELECT '.$cun.' FROM dr_1_news WHERE '.$fieldQuery.''; //资讯


        //

        if ($lb==''){
            $fiaQuery = ' (title LIKE "%'.$tag.'%" OR keywords LIKE "%'.$tag.'%" OR content LIKE "%'.$tag.'%")';  //查询所有字段
        }elseif($lb==1){
            $fiaQuery = ' (title LIKE "%'.$tag.'%")';  //查询标题字段
        }elseif($lb==2){
            $fiaQuery = ' (keywords LIKE "%'.$tag.'%")';  //查询关键词字段
        }elseif($lb==3){
            $fiaQuery = ' (content LIKE "%'.$tag.'%")';  //查询内容字段
        }
        $coua = ' SELECT '.$cun.' FROM dr_1_tix WHERE '.$fiaQuery.''; //提醒
        $coub = ' SELECT '.$cun.' FROM dr_1_zhin WHERE '.$fiaQuery.''; //指南
        $couc = ' SELECT '.$cun.' FROM dr_1_zhuanr WHERE '.$fiaQuery.''; //求车牌
        $coud = ' SELECT '.$cun.' FROM dr_1_qcp WHERE '.$fiaQuery.''; //转让
        $coue = ' SELECT '.$cun.' FROM dr_1_wend WHERE '.$fiaQuery.''; //问答
        $couf = ' SELECT '.$cun.' FROM dr_1_news WHERE '.$fiaQuery.''; //资讯


        //page为空
        if($page==''){
            $sh_list =' ORDER BY inputtime DESC limit 10';
        }else{
            //分页计算
            $sh_list =' ORDER BY inputtime DESC limit '.($page-1)*$limit.','.$limit;
        }

        //数据集 $alltable + 统计 $allnum
        //全部
        if ($lm=='') {
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $counta . ' UNION ALL ' . $countb . ' UNION ALL ' . $countc . ' UNION ALL ' . $countd . ' UNION ALL ' . $counte . ' UNION ALL ' . $countf . ') AS a';
            $alltable = 'SELECT * FROM(' . $tba . ' UNION ALL ' . $tbb . ' UNION ALL ' . $tbc . ' UNION ALL ' . $tbd . ' UNION ALL ' . $tbe . ' UNION ALL ' . $tbf . ') AS a' . $sh_list;
        }
        //统计输出
        $alldate = 'SELECT SUM(b) AS tjall FROM(' . $coua . ' UNION ALL ' . $coub . ' UNION ALL ' . $couc . ' UNION ALL ' . $coud . ' UNION ALL ' . $coue . ' UNION ALL ' . $couf . ') AS a';
        $alln= \Phpcmf\Service::M()->db->query($alldate)->getResultArray();


        //提醒
        if ($lm=='tix'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $counta . ') AS a';
            $alltable = $tba.$sh_list;
        }
        $adate = 'SELECT SUM(b) AS tjall FROM(' . $coua . ') AS a';
        $anum= \Phpcmf\Service::M()->db->query($adate)->getResultArray();

        //求车牌号注意事项
        if ($lm=='txa'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $counta . ' AND catid=16 ) AS a ';
            $alltable = $tba.' AND catid=16'.$sh_list;
        }
        $txadate = 'SELECT SUM(b) AS tjall FROM(' . $coua . ' AND catid=16 ) AS a';
        $txanum= \Phpcmf\Service::M()->db->query($txadate)->getResultArray();

        //京牌转让注意事项
        if ($lm=='txb'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $counta . ' AND catid=17 ) AS a ';
            $alltable = $tba.' AND catid=17'.$sh_list;
        }
        $txbdate = 'SELECT SUM(b) AS tjall FROM(' . $coua . ' AND catid=17 ) AS a';
        $txbnum= \Phpcmf\Service::M()->db->query($txbdate)->getResultArray();

        //买车用车卖车提醒
        if ($lm=='txc'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $counta . ' AND catid=18 ) AS a ';
            $alltable = $tba.' AND catid=18'.$sh_list;
        }
        $txcdate = 'SELECT SUM(b) AS tjall FROM(' . $coua . ' AND catid=18 ) AS a';
        $txcnum= \Phpcmf\Service::M()->db->query($txcdate)->getResultArray();


        //指南
        if ($lm=='zhin'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countb . ') AS a';
            $alltable = $tbb.$sh_list;
        }
        $bdate = 'SELECT SUM(b) AS tjall FROM(' . $coub . ') AS a';
        $bnum= \Phpcmf\Service::M()->db->query($bdate)->getResultArray();
        //北京车牌办理指南
        if ($lm=='zna'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countb . ' AND catid=19 ) AS a ';
            $alltable = $tbb.' AND catid=19'.$sh_list;
        }
        $znadate = 'SELECT SUM(b) AS tjall FROM(' . $coub . ' AND catid=19 ) AS a';
        $znanum= \Phpcmf\Service::M()->db->query($znadate)->getResultArray();
        //北京车牌转让技巧
        if ($lm=='znb'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countb . ' AND catid=20 ) AS a ';
            $alltable = $tbb.' AND catid=20'.$sh_list;
        }
        $znbdate = 'SELECT SUM(b) AS tjall FROM(' . $coub . ' AND catid=20 ) AS a';
        $znbnum= \Phpcmf\Service::M()->db->query($znbdate)->getResultArray();
        //买车用车卖车技巧
        if ($lm=='znc'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countb . ' AND catid=21 ) AS a ';
            $alltable = $tbb.' AND catid=21'.$sh_list;
        }
        $zncdate = 'SELECT SUM(b) AS tjall FROM(' . $coub . ' AND catid=21 ) AS a';
        $zncnum= \Phpcmf\Service::M()->db->query($zncdate)->getResultArray();

        //求车牌
        if ($lm=='zhuanr'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countc . ') AS a';
            $alltable = $tbc.$sh_list;
        }
        $cdate = 'SELECT SUM(b) AS tjall FROM(' . $couc . ') AS a';
        $cnum= \Phpcmf\Service::M()->db->query($cdate)->getResultArray();
        //小汽车指标出租
        if ($lm=='zra'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countc . ' AND catid=12 ) AS a ';
            $alltable = $tbc.' AND catid=12'.$sh_list;
        }
        $zradate = 'SELECT SUM(b) AS tjall FROM(' . $couc . ' AND catid=12 ) AS a';
        $zranum= \Phpcmf\Service::M()->db->query($zradate)->getResultArray();

        //新能源车牌出租
        if ($lm=='zrb'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countc . ' AND catid=13 ) AS a ';
            $alltable = $tbc.' AND catid=13'.$sh_list;
        }
        $zrbdate = 'SELECT SUM(b) AS tjall FROM(' . $couc . ' AND catid=13 ) AS a';
        $zrbnum= \Phpcmf\Service::M()->db->query($zrbdate)->getResultArray();

        //北京车牌出售
        if ($lm=='zrc'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countc . ' AND catid=14 ) AS a ';
            $alltable = $tbc.' AND catid=14'.$sh_list;
        }
        $zrcdate = 'SELECT SUM(b) AS tjall FROM(' . $couc . ' AND catid=14 ) AS a';
        $zrcnum= \Phpcmf\Service::M()->db->query($zrcdate)->getResultArray();

        //靓号车牌转让
        if ($lm=='zrd'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countc . ' AND catid=15 ) AS a ';
            $alltable = $tbc.' AND catid=15'.$sh_list;
        }
        $zrddate = 'SELECT SUM(b) AS tjall FROM(' . $couc . ' AND catid=15 ) AS a';
        $zrdnum= \Phpcmf\Service::M()->db->query($zrddate)->getResultArray();

        //转让
        if ($lm=='qcp'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countd . ') AS a';
            $alltable = $tbd.$sh_list;
        }
        $ddate = 'SELECT SUM(b) AS tjall FROM(' . $coud . ') AS a';
        $dnum= \Phpcmf\Service::M()->db->query($ddate)->getResultArray();
        //求租北京车牌
        if ($lm=='qa'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countd . ' AND catid=8 ) AS a ';
            $alltable = $tbd.' AND catid=8'.$sh_list;
        }
        $qaate = 'SELECT SUM(b) AS tjall FROM(' . $coud . ' AND catid=8 ) AS a';
        $qanum= \Phpcmf\Service::M()->db->query($qaate)->getResultArray();
        //求租新能源车牌
        if ($lm=='qb'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countd . ' AND catid=9 ) AS a ';
            $alltable = $tbd.' AND catid=9'.$sh_list;
        }
        $qbate = 'SELECT SUM(b) AS tjall FROM(' . $coud . ' AND catid=9 ) AS a';
        $qbnum= \Phpcmf\Service::M()->db->query($qbate)->getResultArray();
        //求购京牌指标
        if ($lm=='qc'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countd . ' AND catid=10 ) AS a ';
            $alltable = $tbd.' AND catid=10'.$sh_list;
        }
        $qcate = 'SELECT SUM(b) AS tjall FROM(' . $coud . ' AND catid=10 ) AS a';
        $qcnum= \Phpcmf\Service::M()->db->query($qcate)->getResultArray();
        //求北京车牌靓号
        if ($lm=='qd'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countd . ' AND catid=11 ) AS a ';
            $alltable = $tbd.' AND catid=11'.$sh_list;
        }
        $qdate = 'SELECT SUM(b) AS tjall FROM(' . $coud . ' AND catid=11 ) AS a';
        $qdnum= \Phpcmf\Service::M()->db->query($qdate)->getResultArray();

        //问答
        if ($lm=='wend'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $counte . ') AS a';
            $alltable = $tbe.$sh_list;
        }
        $edate = 'SELECT SUM(b) AS tjall FROM(' . $coue . ') AS a';
        $enum= \Phpcmf\Service::M()->db->query($edate)->getResultArray();
        //求租北京车牌
        if ($lm=='wda'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $counte . ' AND catid=22 ) AS a ';
            $alltable = $tbe.' AND catid=22'.$sh_list;
        }
        $wdaate = 'SELECT SUM(b) AS tjall FROM(' . $coue . ' AND catid=22 ) AS a';
        $wdanum= \Phpcmf\Service::M()->db->query($wdaate)->getResultArray();
        //求租新能源车牌
        if ($lm=='wdb'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $counte . ' AND catid=23 ) AS a ';
            $alltable = $tbe.' AND catid=23'.$sh_list;
        }
        $wdbate = 'SELECT SUM(b) AS tjall FROM(' . $coue . ' AND catid=23 ) AS a';
        $wdbnum= \Phpcmf\Service::M()->db->query($wdbate)->getResultArray();
        //求购京牌指标
        if ($lm=='wdc'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $counte . ' AND catid=24 ) AS a ';
            $alltable = $tbe.' AND catid=24'.$sh_list;
        }
        $wdcate = 'SELECT SUM(b) AS tjall FROM(' . $coue . ' AND catid=24 ) AS a';
        $wdcnum= \Phpcmf\Service::M()->db->query($wdcate)->getResultArray();

        //资讯
        if ($lm=='news'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countf . ') AS a';
            $alltable = $tbf.$sh_list;
        }
        $fdate = 'SELECT SUM(b) AS tjall FROM(' . $couf . ') AS a';
        $fnum= \Phpcmf\Service::M()->db->query($fdate)->getResultArray();
        //车牌指标
        if ($lm=='na'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countf . ' AND catid=25 ) AS a ';
            $alltable = $tbf.' AND catid=25'.$sh_list;
        }
        $naate = 'SELECT SUM(b) AS tjall FROM(' . $couf . ' AND catid=25 ) AS a';
        $nanum= \Phpcmf\Service::M()->db->query($naate)->getResultArray();
        //汽车资讯
        if ($lm=='nb'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countf . ' AND catid=26 ) AS a ';
            $alltable = $tbf.' AND catid=26'.$sh_list;
        }
        $nbate = 'SELECT SUM(b) AS tjall FROM(' . $couf . ' AND catid=26 ) AS a';
        $nbnum= \Phpcmf\Service::M()->db->query($nbate)->getResultArray();
        //杂谈热点
        if ($lm=='nc'){
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $countf . ' AND catid=27 ) AS a ';
            $alltable = $tbf.' AND catid=27'.$sh_list;
        }
        $ncate = 'SELECT SUM(b) AS tjall FROM(' . $couf . ' AND catid=27 ) AS a';
        $ncnum= \Phpcmf\Service::M()->db->query($ncate)->getResultArray();

        //栏目名
        $lmm = array([
            1=>'全部',2=>'重要提醒',3=>'求车牌号注意事项',4=>'京牌转让注意事项',5=>'买车用车卖车提醒',6=>'科普指南',7=>'北京车牌办理指南',8=>'北京车牌转让技巧',9=>'买车用车卖车技巧',10=>'我求车牌号',
            11=>'小汽车指标出租',12=>'新能源车牌出租',13=>'北京车牌出售',14=>'靓号车牌转让',15=>'我有牌转让',16=>'求租北京车牌',17=>'求租新能源车牌',18=>'求购京牌指标',19=>'求北京车牌靓号',20=>'常见问答',
            21=>'求车牌号常见问答',22=>'京牌转让常见问题',23=>'买车用车卖车答疑',24=>'宝典资讯',25=>'车牌指标',26=>'汽车资讯',27=>'杂谈热点',
        ]);

        if($lm==''){$lmm=$lmm[0][1];}elseif($lm=='tix'){$lmm=$lmm[0][2];}elseif($lm=='txa'){$lmm=$lmm[0][3];}elseif($lm=='txb'){$lmm=$lmm[0][4];}elseif($lm=='txc'){$lmm=$lmm[0][5];}elseif($lm=='zhin'){$lmm =$lmm[0][6];}elseif($lm=='zna'){$lmm=$lmm[0][7];}elseif($lm=='znb'){$lmm=$lmm[0][8];}elseif($lm=='znc'){$lmm=$lmm[0][9];}elseif($lm=='zhuanr'){$lmm=$lmm[0][10];}elseif($lm=='zra'){$lmm=$lmm[0][11];}elseif($lm=='zrb'){$lmm=$lmm[0][12];}elseif($lm=='zrc'){$lmm=$lmm[0][13];}elseif($lm=='zrd'){$lmm=$lmm[0][14]; }elseif($lm=='qcp'){$lmm=$lmm[0][15];}elseif($lm=='qa'){$lmm=$lmm[0][16];}elseif($lm=='qb'){$lmm=$lmm[0][17];}elseif($lm=='qc'){$lmm=$lmm[0][18];}elseif($lm=='qd'){$lmm=$lmm[0][19];}elseif($lm=='wend'){$lmm=$lmm[0][20];}elseif($lm=='wda'){$lmm=$lmm[0][21];}elseif($lm=='wdb'){ $lmm=$lmm[0][22];}elseif($lm=='wdc'){$lmm=$lmm[0][23];}elseif($lm=='news'){$lmm=$lmm[0][24];}elseif($lm=='na'){$lmm=$lmm[0][25];}elseif($lm=='nb'){$lmm=$lmm[0][26];}elseif($lm=='nc'){$lmm=$lmm[0][27];}

        //记录总数
        $list_total = \Phpcmf\Service::M()->db->query($allnum)->getResultArray();
        $total_nums = $list_total[0]['tjall'];

        //数据集
        $list = \Phpcmf\Service::M()->db->query($alltable)->getResultArray();

        end:
        \Phpcmf\Service::V()->assign([
            'datas'         =>  $datas,  //热门标签
            'meta_title'    =>  $tag.' - 标签云',
            'lmm'           =>  $lmm,   //栏目名称
            'alln'          =>  $alln[0]['tjall'],  //全部条数
            'anum'          =>  $anum[0]['tjall'],  //提醒
            'txanum'        =>  $txanum[0]['tjall'],  //求车牌号注意事项
            'txbnum'        =>  $txbnum[0]['tjall'],  //京牌转让注意事项
            'txcnum'        =>  $txcnum[0]['tjall'],  //买车用车卖车提醒
            'bnum'          =>  $bnum[0]['tjall'],  //指南
            'znanum'        =>  $znanum[0]['tjall'],  //北京车牌办理指南
            'znbnum'        =>  $znbnum[0]['tjall'],  //北京车牌转让技巧
            'zncnum'        =>  $zncnum[0]['tjall'],  //买车用车卖车技巧
            'cnum'          =>  $cnum[0]['tjall'],  //求牌
            'zranum'        =>  $zranum[0]['tjall'],  //小汽车指标出租
            'zrbnum'        =>  $zrbnum[0]['tjall'],  //新能源车牌出租
            'zrcnum'        =>  $zrcnum[0]['tjall'],  //北京车牌出售
            'zrdnum'        =>  $zrdnum[0]['tjall'],  //靓号车牌转让
            'dnum'          =>  $dnum[0]['tjall'],  //转让
            'qanum'         =>  $qanum[0]['tjall'],  //求租北京车牌
            'qbnum'         =>  $qbnum[0]['tjall'],  //求租新能源车牌
            'qcnum'         =>  $qcnum[0]['tjall'],  //求购京牌指标
            'qdnum'         =>  $qdnum[0]['tjall'],  //求北京车牌靓号
            'enum'          =>  $enum[0]['tjall'],  //问答
            'wdanum'        =>  $wdanum[0]['tjall'],  //求车牌号常见问答
            'wdbnum'        =>  $wdbnum[0]['tjall'],  //京牌转让常见问题
            'wdcnum'        =>  $wdcnum[0]['tjall'],  //买车用车卖车答疑
            'fnum'          =>  $fnum[0]['tjall'],  //资讯
            'nanum'         =>  $nanum[0]['tjall'],  //车牌指标
            'nbnum'         =>  $nbnum[0]['tjall'],  //汽车资讯
            'ncnum'         =>  $ncnum[0]['tjall'],  //杂谈热点
            'keyword'       =>  $keyword,
            'total_nums'    =>  $total_nums, //记录总数
            'total_pages'   =>  $total_pages, //总页数
            'page'          =>  $page,   //当前页
            'list'          =>  $list, //查询结果
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/index', ['name' => $keyword,'lm' => $lm,'lb' => $lb]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('tag.html');
    }

    public function jiansuo($jsl,$jslrq,$tagId){
        
        if(empty($jslrq)){
            for ($x=0; $x<=6; $x++) {
                $jslrq[1][$x+1] = date("Y-m-d",strtotime("-".(6 - $x)." day"));
                if($x == 6){
                    $jsl[1][$x+1] = 1;
                }else{
                    $jsl[1][$x+1] = null;
                }

            }
            $data = array(
                'jslrq' => serialize($jslrq),
                'jsl' => serialize($jsl)
            );
        }else{
            $jsls[1] = $jsl;
            $jslrqs[1] = $jslrq;

            if(in_array(date("Y-m-d"),$jslrq)){
                $jsls[1][7] = (int)$jsls[1][7] + 1;
            }else{
                for ($x=0; $x<=6; $x++) {
                    if($x == 6){
                        $jsls[1][$x+1] = 1;
                        $jslrqs[1][$x+1] = date("Y-m-d");
                    }else{
                        $jslrqs[1][$x+1] = date("Y-m-d",strtotime("-".(6 - $x)." day"));
                        if(in_array($jslrqs[1][$x+1],$jslrq)){
                            $jsls[1][$x+1] = $jsl[array_search($jslrqs[1][$x+1],$jslrq)];
                        }else{
                            $jsls[1][$x+1] = null;
                        }
                    }
                }
            }
            $data = array(
                'jslrq' => serialize($jslrqs),
                'jsl' => serialize($jsls)
            );

        }
        \Phpcmf\Service::M()->db->table('dr_1_tag')->where('id', (int)$tagId)->update($data);
    }


    //标签云列表
    public function tagCloud()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数

        if($type=='1'){
            $total_nums = \Phpcmf\Service::M()->table($this->table)->where(" titnum > 0 ")->counts();  //标题
        }elseif($type=='2'){
            $total_nums = \Phpcmf\Service::M()->table($this->table)->where(" gjzzs > 0 ")->counts();  //关键词
        }elseif($type=='3'){
            $total_nums = \Phpcmf\Service::M()->table($this->table)->where(" nrzs > 0 ")->counts();  //关键词
        }else{
            $total_nums = \Phpcmf\Service::M()->table($this->table)->where(" zongs > 0 ")->counts();  //数据总数
        }
        $page_nums =  ceil($total_nums/$limit);                 //总页数

        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }

        //数据类型
        if($type=='1'){
            $list = \Phpcmf\Service::M()->db->table($this->table)->where(' titnum > 0 ')->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();
        }elseif($type=='2'){
            $list = \Phpcmf\Service::M()->db->table($this->table)->where(' gjzzs > 0 ')->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();
        }elseif($type=='3'){
            $list = \Phpcmf\Service::M()->db->table($this->table)->where(' nrzs > 0 ')->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();
        }else{
            $list = \Phpcmf\Service::M()->db->table($this->table)->where(" zongs > 0 ")->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();
        }


        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'datas'         =>  $datas,  //热门标签
            'list'          =>  $list,  //数据集
            'total_total'   =>  $this->total_total,  //数据总数
            'total_nums'    =>  $total_nums,         //类型总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,    //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/tagcloud',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('tag_cloud.html');
    }

    //标签云列表 / 宝典咨询
    public function tagNews()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //资讯标签总数
        $total_zx = \Phpcmf\Service::M()->table($this->table)->where(" bdzxzs > 0 ")->counts();
        //资讯类型
        if($type=='1'){
            $wh = " bdzxbtcs > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " bdgjccs > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " bdnrcs > 0 ";  //内容
        }else{
            $wh = " bdzxzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts(); //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'datas'         =>  $datas,  //热门标签
            'list'          =>  $list,  //数据集
            'total_total'   =>  $this->total_total,  //数据总数
            'total_zx'      =>  $total_zx,          //资讯数据总数
            'total_nums'    =>  $total_nums,        //类型总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/tagnews',['type' => $type]), $total_nums,$limit),

        ]);

        \Phpcmf\Service::V()->display('tag_news.html');
    }

    //标签云列表 / 我有牌转让
    public function tagQcp()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totald_zr = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " zrbtcs > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " zrgjccs > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " zrnrcs > 0 ";  //内容
        }else{
            $wh = " zrzcs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($totald_zr/$limit);     //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }

        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'datas'         =>  $datas,  //热门标签
            'list'          =>  $list,  //数据集
            'total_total'   =>  $this->total_total,  //数据总数
            'totald_zr'     =>  $totald_zr, //转让总数
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/tagqcp',['type' => $type]), $total_nums,$limit),

        ]);

        \Phpcmf\Service::V()->display('tag_qcp.html');
    }

    //标签云列表 / 我求车牌号
    public function tagZhuanr()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totalc_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " qcpbtcs > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " qcpgjccs > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " qcpnrcs > 0 ";  //内容
        }else{
            $wh = " qcpzcs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'datas'         =>  $datas,  //热门标签
            'list'          =>  $list,  //数据集
            'total_total'   =>  $this->total_total,  //数据总数
            'totalc_zs'     =>  $totalc_zs,  //求车牌总数
            'total_nums'    =>  $total_nums, //类型总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/tagzhuanr',['type' => $type]), $total_nums,$limit),

        ]);

        \Phpcmf\Service::V()->display('tag_zhuanr.html');
    }

    //标签云列表 / 重要提醒
    public function tagTix()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totala_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " txbtcs > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " txgjccs > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " txnrcs > 0 ";  //内容
        }else{
            $wh = " txzcs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totala_zs'     =>  $totala_zs,     //数据总数
            'total_nums'    =>  $total_nums,    //tdk总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/tagtix',['type' => $type]), $total_nums,$limit),

        ]);

        \Phpcmf\Service::V()->display('tag_tix.html');
    }

    //标签云列表 / 科普指南
    public function tagZhin()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totalb_zs = \Phpcmf\Service::M()->table($this->table)->counts();

        //tdk类型
        if($type=='1'){
            $wh = " znbtcs > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " zngjccs > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " znnrcs > 0 ";  //内容
        }else{
            $wh = " znzcs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数

        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据类型
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totalb_zs'     =>  $totalb_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/tagzhin',['type' => $type]), $total_nums,$limit),

        ]);

        \Phpcmf\Service::V()->display('tag_zhin.html');
    }

    //标签云列表 / 常见问答
    public function tagWend()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " wdbtcs > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " wdgjccs > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " wdnrcs > 0 ";  //内容
        }else{
            $wh = " wdzcs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/tagwend',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('tag_wend.html');
    }

    //标签云列表 / 求车牌号注意事项
    public function txa()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " qpzybt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " qpzygjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " qpzynr > 0 ";  //内容
        }else{
            $wh = " qpzyzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/txa',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('txa.html');
    }

    //标签云列表 / 京牌转让注意事项
    public function txb()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " zrzybt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " zrzygjz > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " zrzynr > 0 ";  //内容
        }else{
            $wh = " zrzyzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/txb',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('txb.html');
    }

    //标签云列表 / 买车用车卖车提醒
    public function txc()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " myctxbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " myctxgjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " myctxnr > 0 ";  //内容
        }else{
            $wh = " myctxzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/txc',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('txc.html');
    }

    //标签云列表 / 北京车牌办理指南
    public function zna()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " blznbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " blzngjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " blznnr > 0 ";  //内容
        }else{
            $wh = " blznzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/zna',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('zna.html');
    }
    //标签云列表 / 北京车牌转让技巧
    public function znb()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " zrjqbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " zrjqgjz > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " zrjqnr > 0 ";  //内容
        }else{
            $wh = " zrjqzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/znb',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('znb.html');
    }
    //标签云列表 / 买车用车卖车技巧
    public function znc()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " mcjqbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " mcjqgjz > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " mcjqnr > 0 ";  //内容
        }else{
            $wh = " mcjqzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/znc',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('znc.html');
    }

    //标签云列表 / 小汽车指标出租
    public function qpa()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " zbczbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " zbczgjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " zbcznr > 0 ";  //内容
        }else{
            $wh = " zbczzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/qpa',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('qpa.html');
    }

    //标签云列表 / 北京车牌出售
    public function qpb()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " cpczbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " cpczgjz > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " cpcznr > 0 ";  //内容
        }else{
            $wh = " cpczzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/qpb',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('qpb.html');
    }

    //标签云列表 / 北京车牌出售
    public function qpc()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " cpcsbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " cpcsgjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " cpcsnr > 0 ";  //内容
        }else{
            $wh = " cpcszs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/qpc',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('qpc.html');
    }

    //标签云列表 / 靓号车牌转让
    public function qpd()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " cpzrbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " cpzrgjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " cpzrnr > 0 ";  //内容
        }else{
            $wh = " cpzrzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/qpd',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('qpd.html');
    }

    //标签云列表 / 靓号车牌转让
    public function zra()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " qzcpbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " qzcpgjz > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " qzcpnr > 0 ";  //内容
        }else{
            $wh = " qzcpzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/zra',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('zra.html');
    }
    //标签云列表 / 求租新能源车牌
    public function zrb()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " xnybt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " xnygjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " xnynr > 0 ";  //内容
        }else{
            $wh = " xnyzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/zrb',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('zrb.html');
    }
    //标签云列表 / 求购京牌指标
    public function zrc()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " jpzbbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " jpzbgjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " jpzbnr > 0 ";  //内容
        }else{
            $wh = " jpzbzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/zrc',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('zrc.html');
    }
    //标签云列表 / 求北京车牌靓号
    public function zrd()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " cpjhbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " cpjhgjz > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " cpjhnr > 0 ";  //内容
        }else{
            $wh = " cpjhzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/zrd',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('zrd.html');
    }
    //标签云列表 / 求车牌号常见问答
    public function wda()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " qpwdbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " qpwdgjz > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " qpwdnr > 0 ";  //内容
        }else{
            $wh = " qpwdzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/wda',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('wda.html');
    }
    //标签云列表 / 京牌转让常见问题
    public function wdb()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " zrwdbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " zrwdgjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " zrwdnr > 0 ";  //内容
        }else{
            $wh = " zrwdzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/wdb',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('wdb.html');
    }
    //标签云列表 / 买车用车卖车答疑
    public function wdc()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " dayibt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " dygjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " dayinr > 0 ";  //内容
        }else{
            $wh = " dyzss > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/wdc',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('wdc.html');
    }

    //标签云列表 / 车牌指标
    public function zxa()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " cpzbbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " cpzbgjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " cpzbnr > 0 ";  //内容
        }else{
            $wh = " cpzbzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/zxa',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('zxa.html');
    }
    //标签云列表 / 汽车资讯
    public function zxb()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " qczxbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " qczxgjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " qczxnr > 0 ";  //内容
        }else{
            $wh = " qczxzs > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/zxb',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('zxb.html');
    }
    //标签云列表 / 汽车资讯
    public function zxc()
    {
        $datas = \Phpcmf\Service::M('app')->get_config(APP_DIR);
        //类型
        $type = (int)\Phpcmf\Service::L('input')->get('type');
        //当前页码
        $page = (int)\Phpcmf\Service::L('input')->get('page');
        //分页设置
        $pagenum = 0; //分页默认起始位置
        $limit = $this->cachenum['tag_num'];     //每页显示记录条数
        //总数
        $totale_zs = \Phpcmf\Service::M()->table($this->table)->counts();
        //tdk类型
        if($type=='1'){
            $wh = " ztrdbt > 0 ";  //标题
        }elseif($type=='2'){
            $wh = " ztrdgjc > 0 ";  //关键词
        }elseif($type=='3'){
            $wh = " ztrdnr > 0 ";  //内容
        }else{
            $wh = " ztrd > 0 "; //数据总数
        }
        $total_nums = \Phpcmf\Service::M()->table($this->table)->where($wh)->counts();  //统计
        $page_nums =  ceil($total_nums/$limit);                 //总页数
        //page为空
        if($page==''){
            $dqys = $pagenum;
        }else{
            $dqys = (($page - 1) * $limit ) + 0;
        }
        //数据集
        $list = \Phpcmf\Service::M()->db->table($this->table)->where($wh)->orderBy($this->order)->limit($limit,$dqys)->get()->getResultArray();

        \Phpcmf\Service::V()->assign([
            'meta_title'    => '标签云',
            'list'          =>  $list,  //数据集
            'datas'         =>  $datas,  //热门标签
            'total_total'   =>  $this->total_total,  //数据总数
            'totale_zs'     =>  $totale_zs,
            'total_nums'    =>  $total_nums, //数据总数
            'totala'        =>  $this->totala,       //提醒
            'txa'           =>  $this->txa,
            'txb'           =>  $this->txb,
            'txc'           =>  $this->txc,
            'totalb'        =>  $this->totalb,       //指南
            'zna'           =>  $this->zna,
            'znb'           =>  $this->znb,
            'znc'           =>  $this->znc,
            'totalc'        =>  $this->totalc,       //求车牌
            'qpa'           =>  $this->qpa,
            'qpb'           =>  $this->qpb,
            'qpc'           =>  $this->qpc,
            'qpd'           =>  $this->qpd,
            'totald'        =>  $this->totald,       //转让
            'zra'           =>  $this->zra,
            'zrb'           =>  $this->zrb,
            'zrc'           =>  $this->zrc,
            'zrd'           =>  $this->zrd,
            'totale'        =>  $this->totale,       //问答
            'wda'           =>  $this->wda,
            'wdb'           =>  $this->wdb,
            'wdc'           =>  $this->wdc,
            'totalf'        =>  $this->totalf,       //资讯
            'zxa'           =>  $this->zxa,
            'zxb'           =>  $this->zxb,
            'zxc'           =>  $this->zxc,
            'page_nums'     =>  $page_nums,  //总页数
            'page_limit'    =>  $limit,  //每页总数（每页内容数量）
            'page'          =>  $page,  //当前页数
            'mypages'	    =>  $this->mypage(\Phpcmf\Service::L('Router')->url('tag/home/zxc',['type' => $type]), $total_nums,$limit),
        ]);

        \Phpcmf\Service::V()->display('zxc.html');
    }


}
