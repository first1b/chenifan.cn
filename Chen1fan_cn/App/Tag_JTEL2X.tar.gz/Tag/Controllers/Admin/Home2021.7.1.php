<?php namespace Phpcmf\Controllers\Admin;


// 内容模块tag操作类 基于 Ftable
class Home extends \Phpcmf\Table
{
    public $pid;

    public function __construct(...$params) {
        parent::__construct(...$params);
        // 支持附表存储
        $this->is_data = 0;
        // 模板前缀(避免混淆)
        $this->tpl_prefix = 'tag_';
        // 单独模板命名
        $this->tpl_name = 'tag_content';
        // 模块显示名称
        $this->name = dr_lang('Tag');
        // pid
        $this->pid = intval(\Phpcmf\Service::L('input')->get('pid'));
        $myfield = [
            'name' => [
                'ismain' => 1,
                'name' => dr_lang('名称'),
                'fieldname' => 'name',
                'fieldtype' => 'Text',
                'setting' => array(
                    'option' => array(
                        'width' => 200,
                    ),
                    'is_right' => 2,
                )
            ],
            'displayorder' => array(
                'name' => dr_lang('权重值'),
                'ismain' => 1,
                'fieldtype' => 'Touchspin',
                'fieldname' => 'displayorder',
                'setting' => array(
                    'option' => array(
                        'width' => 200,
                        'max' => '999999999',
                        'min' => '0',
                        'step' => '1',
                        'show' => '1',
                        'value' => 0
                    ),
                    'validate' => array(
                        'tips' => dr_lang('权重值越高排列越靠前'),
                    )
                )
            ),
            'content' => [
                'ismain' => 1,
                'name' => dr_lang('描述信息'),
                'fieldname' => 'content',
                'fieldtype' => 'Ueditor',
                'setting' => array(
                    'option' => array(
                        'mode' => 1,
                        'height' => 300,
                        'width' => '100%',
                    ),
                )
            ],
        ];
        // 初始化数据表
        $this->_init([
            'table' => SITE_ID.'_tag',
            'field' => dr_array22array($myfield, \Phpcmf\Service::L('cache')->get('tag-'.SITE_ID.'-field')),
            'show_field' => 'name',
            'sys_field' => ['content'],
            'where_list' => 'pid='.$this->pid,
            'order_by' => 'displayorder DESC,id ASC',
        ]);
        \Phpcmf\Service::V()->assign([
            'pid' => $this->pid,
            'menu' => \Phpcmf\Service::M('auth')->_admin_menu(
                [
                    '关键词' => [APP_DIR.'/'.\Phpcmf\Service::L('Router')->class.'/index', 'fa fa-tag'],
                    '添加' => [APP_DIR.'/'.\Phpcmf\Service::L('Router')->class.'/add', 'fa fa-plus'],
                    '修改' => ['hide:'.APP_DIR.'/'.\Phpcmf\Service::L('Router')->class.'/edit', 'fa fa-edit'],
                    '批量添加' => [APP_DIR.'/'.\Phpcmf\Service::L('Router')->class.'/all_add', 'fa fa-plus-square-o'],
                    '自定义字段' => ['url:'.\Phpcmf\Service::L('Router')->url('field/index', ['rname' => 'tag', 'rid'=>SITE_ID]), 'fa fa-code'],
                    'help' => [63]
                ]
            ),
            'field' => $this->init['field'],
        ]);
    }

    // ========================
    public function gengxin(){
        $rt = \Phpcmf\Service::M()->db->query("select `id` from dr_1_tag");
        $rows = $rt->getResultArray();

        foreach ($rows AS $key=>$val){
            //标签名称
            $tag_title = \Phpcmf\Service::M()->table(SITE_ID.'_tag')->where('id',$val['id'])->getRow();

            //标签名称
            $tagName = trim($tag_title['name']);

            //相关词数量
            $sqlxg = 'SELECT * FROM dr_1_tag AS a WHERE a.name LIKE "%'.$tagName.'%"';
            $xgcnum = \Phpcmf\Service::M()->db->query($sqlxg)->getResultArray();
            //相关词数量更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'xgcsl'    => count($xgcnum),
            ]);

            //统计字段
            $tit_num = 'ROUND(sum((LENGTH(`title`) - LENGTH(REPLACE(`title`,"'.$tagName.'", ""))) / LENGTH("'.$tagName.'")))';
            $key_num = 'ROUND(sum((LENGTH(`keywords`) - LENGTH(REPLACE(`keywords`,"'.$tagName.'", ""))) / LENGTH("'.$tagName.'")))';
            $des_num = 'ROUND(sum((LENGTH(`description`) - LENGTH(REPLACE(`description`,"'.$tagName.'", ""))) / LENGTH("'.$tagName.'")))';
            //$con_num = 'ROUND(sum((LENGTH(`content`) - LENGTH(REPLACE(`content`,"'.$tagName.'", ""))) / LENGTH("'.$tagName.'")))';

            //提醒统计
            //$counts_tix = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" ,'.$con_num.' AS "numd"  FROM dr_1_tix';
            $counts_tix = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc"  FROM dr_1_tix';
            $tabd= \Phpcmf\Service::M()->db->query($counts_tix)->getResultArray();
            //$total_tix = (int)$tabd[0]['numa']+$tabd[0]['numb']+$tabd[0]['numc']+$tabd[0]['numd']; //当前表总数
            $total_tix = (int)$tabd[0]['numa']+$tabd[0]['numb']+$tabd[0]['numc']; //当前表总数
            $total_tix_tit = (int)$tabd[0]['numa']; //标题次数
            $total_tix_key = (int)$tabd[0]['numb']; //关键词次数
            $total_tix_con = (int)$tabd[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'txzcs'     => $total_tix,
                'txbtcs'    => $total_tix_tit,
                'txgjccs'   => $total_tix_key,
                'txnrcs'    => $total_tix_con,
            ]);

            //求车牌号注意事项
            $tix_a = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb",'.$des_num.' AS "numc"  FROM dr_1_tix WHERE catid=16';
            $tx_a = \Phpcmf\Service::M()->db->query($tix_a)->getResultArray();
            $tixa_zs = (int)$tx_a[0]['numa']+$tx_a[0]['numb']+$tx_a[0]['numc']; //当前表总数
            $tixa_tit_zs = (int)$tx_a[0]['numa']; //标题次数
            $tixa_key_zs = (int)$tx_a[0]['numb']; //关键词次数
            $tixa_con_zs = (int)$tx_a[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'qpzyzs'    => $tixa_zs,
                'qpzybt'    => $tixa_tit_zs,
                'qpzygjc'   => $tixa_key_zs,
                'qpzynr'    => $tixa_con_zs,
            ]);

            //京牌转让注意事项
            $tix_b = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc"  FROM dr_1_tix WHERE catid=17';
            $tx_b = \Phpcmf\Service::M()->db->query($tix_b)->getResultArray();
            $tixb_zs = (int)$tx_b[0]['numa']+$tx_b[0]['numb']+$tx_b[0]['numc']; //当前表总数
            $tixb_tit_zs = (int)$tx_b[0]['numa']; //标题次数
            $tixb_key_zs = (int)$tx_b[0]['numb']; //关键词次数
            $tixb_con_zs = (int)$tx_b[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zrzyzs'    => $tixb_zs,
                'zrzybt'    => $tixb_tit_zs,
                'zrzygjz'   => $tixb_key_zs,
                'zrzynr'    => $tixb_con_zs,
            ]);

            //买车用车卖车提醒
            $tix_c = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc"  FROM dr_1_tix WHERE catid=18';
            $tx_c = \Phpcmf\Service::M()->db->query($tix_c)->getResultArray();
            $tixc_zs = (int)$tx_c[0]['numa']+$tx_c[0]['numb']+$tx_c[0]['numc']; //当前表总数
            $tixc_tit_zs = (int)$tx_c[0]['numa']; //标题次数
            $tixc_key_zs = (int)$tx_c[0]['numb']; //关键词次数
            $tixc_con_zs = (int)$tx_c[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'myctxzs'    => $tixc_zs,
                'myctxbt'    => $tixc_tit_zs,
                'myctxgjc'   => $tixc_key_zs,
                'myctxnr'    => $tixc_con_zs,
            ]);

            //zhin统计
            $counts_zhin = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_zhin';
            $tabe = \Phpcmf\Service::M()->db->query($counts_zhin)->getResultArray();
            $total_zhin = (int)$tabe[0]['numa']+$tabe[0]['numb']+$tabe[0]['numc']; //当前表总数
            $total_zhin_tit = (int)$tabe[0]['numa']; //标题次数
            $total_zhin_key = (int)$tabe[0]['numb']; //关键词次数
            $total_zhin_con = (int)$tabe[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'znzcs'     => $total_zhin,
                'znbtcs'    => $total_zhin_tit,
                'zngjccs'   => $total_zhin_key,
                'znnrcs'    => $total_zhin_con,
            ]);

            //北京车牌办理指南
            $zhin_a = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc"  FROM dr_1_zhin WHERE catid=19';
            $zn_a = \Phpcmf\Service::M()->db->query($zhin_a)->getResultArray();
            $zhina_zs = (int)$zn_a[0]['numa']+$zn_a[0]['numb']+$zn_a[0]['numc']; //当前表总数
            $zhina_tit_zs = (int)$zn_a[0]['numa']; //标题次数
            $zhina_key_zs = (int)$zn_a[0]['numb']; //关键词次数
            $zhina_con_zs = (int)$zn_a[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'blznzs'    => $zhina_zs,
                'blznbt'    => $zhina_tit_zs,
                'blzngjc'   => $zhina_key_zs,
                'blznnr'    => $zhina_con_zs,
            ]);

            //北京车牌转让技巧
            $zhin_b = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_zhin WHERE catid=20';
            $zn_b = \Phpcmf\Service::M()->db->query($zhin_b)->getResultArray();
            $zhinb_zs = (int)$zn_b[0]['numa']+$zn_b[0]['numb']+$zn_b[0]['numc']; //当前表总数
            $zhinb_tit_zs = (int)$zn_b[0]['numa']; //标题次数
            $zhinb_key_zs = (int)$zn_b[0]['numb']; //关键词次数
            $zhinb_con_zs = (int)$zn_b[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zrjqzs'    => $zhinb_zs,
                'zrjqbt'    => $zhinb_tit_zs,
                'zrjqgjz'   => $zhinb_key_zs,
                'zrjqnr'    => $zhinb_con_zs,
            ]);

            //买车用车卖车技巧
            $zhin_c = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_zhin WHERE catid=21';
            $zn_c = \Phpcmf\Service::M()->db->query($zhin_c)->getResultArray();
            $zhinc_zs = (int)$zn_c[0]['numa']+$zn_c[0]['numb']+$zn_c[0]['numc']; //当前表总数
            $zhinc_tit_zs = (int)$zn_c[0]['numa']; //标题次数
            $zhinc_key_zs = (int)$zn_c[0]['numb']; //关键词次数
            $zhinc_con_zs = (int)$zn_c[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'mcjqzs'    => $zhinc_zs,
                'mcjqbt'    => $zhinc_tit_zs,
                'mcjqgjz'   => $zhinc_key_zs,
                'mcjqnr'    => $zhinc_con_zs,
            ]);

            //求车牌统计
            $counts_zhuanr = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_zhuanr';
            $tabc = \Phpcmf\Service::M()->db->query($counts_zhuanr)->getResultArray();
            $total_zhuanr = (int)$tabc[0]['numa']+$tabc[0]['numb']+$tabc[0]['numc']; //当前表总数
            $total_zhuanr_tit = (int)$tabc[0]['numa']; //标题次数
            $total_zhuanr_key = (int)$tabc[0]['numb']; //关键词次数
            $total_zhuanr_con = (int)$tabc[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'qcpzcs'     => $total_zhuanr,
                'qcpbtcs'    => $total_zhuanr_tit,
                'qcpgjccs'   => $total_zhuanr_key,
                'qcpnrcs'    => $total_zhuanr_con,
            ]);

            //小汽车指标出租
            $zhuanr_a = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_zhuanr WHERE catid=12';
            $zr_a = \Phpcmf\Service::M()->db->query($zhuanr_a)->getResultArray();
            $zhuanra_zs = (int)$zr_a[0]['numa']+$zr_a[0]['numb']+$zr_a[0]['numc']; //当前表总数
            $zhuanra_tit_zs = (int)$zr_a[0]['numa']; //标题次数
            $zhuanra_key_zs = (int)$zr_a[0]['numb']; //关键词次数
            $zhuanra_con_zs = (int)$zr_a[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zbczzs'    => $zhuanra_zs,
                'zbczbt'    => $zhuanra_tit_zs,
                'zbczgjc'   => $zhuanra_key_zs,
                'zbcznr'    => $zhuanra_con_zs,
            ]);

            //新能源车牌出租
            $zhuanr_b = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_zhuanr WHERE catid=13';
            $zr_b = \Phpcmf\Service::M()->db->query($zhuanr_b)->getResultArray();
            $zhuanrb_zs = (int)$zr_b[0]['numa']+$zr_b[0]['numb']+$zr_b[0]['numc']; //当前表总数
            $zhuanrb_tit_zs = (int)$zr_b[0]['numa']; //标题次数
            $zhuanrb_key_zs = (int)$zr_b[0]['numb']; //关键词次数
            $zhuanrb_con_zs = (int)$zr_b[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'cpczzs'    => $zhuanrb_zs,
                'cpczbt'    => $zhuanrb_tit_zs,
                'cpczgjz'   => $zhuanrb_key_zs,
                'cpcznr'    => $zhuanrb_con_zs,
            ]);

            //北京车牌出售
            $zhuanr_c = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_zhuanr WHERE catid=14';
            $zr_c = \Phpcmf\Service::M()->db->query($zhuanr_c)->getResultArray();
            $zhuanrc_zs = (int)$zr_c[0]['numa']+$zr_c[0]['numb']+$zr_c[0]['numc']; //当前表总数
            $zhuanrc_tit_zs = (int)$zr_c[0]['numa']; //标题次数
            $zhuanrc_key_zs = (int)$zr_c[0]['numb']; //关键词次数
            $zhuanrc_con_zs = (int)$zr_c[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'cpcszs'    => $zhuanrc_zs,
                'cpcsbt'    => $zhuanrc_tit_zs,
                'cpcsgjc'   => $zhuanrc_key_zs,
                'cpcsnr'    => $zhuanrc_con_zs,
            ]);

            //靓号车牌转让
            $zhuanr_d = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_zhuanr WHERE catid=15';
            $zr_d = \Phpcmf\Service::M()->db->query($zhuanr_d)->getResultArray();
            $zhuanrd_zs = (int)$zr_d[0]['numa']+$zr_d[0]['numb']+$zr_d[0]['numc']; //当前表总数
            $zhuanrd_tit_zs = (int)$zr_d[0]['numa']; //标题次数
            $zhuanrd_key_zs = (int)$zr_d[0]['numb']; //关键词次数
            $zhuanrd_con_zs = (int)$zr_d[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'cpzrzs'    => $zhuanrd_zs,
                'cpzrbt'    => $zhuanrd_tit_zs,
                'cpzrgjc'   => $zhuanrd_key_zs,
                'cpzrnr'    => $zhuanrd_con_zs,
            ]);


            //转让统计
            $counts_qcp = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_qcp';
            $tabb = \Phpcmf\Service::M()->db->query($counts_qcp)->getResultArray();
            $total_qcp = (int)$tabb[0]['numa']+$tabb[0]['numb']+$tabb[0]['numc']; //当前表总数
            $total_qcp_tit = (int)$tabb[0]['numa']; //标题次数
            $total_qcp_key = (int)$tabb[0]['numb']; //关键词次数
            $total_qcp_con = (int)$tabb[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zrzcs'     => $total_qcp,
                'zrbtcs'    => $total_qcp_tit,
                'zrgjccs'   => $total_qcp_key,
                'zrnrcs'    => $total_qcp_con,
            ]);

            //求租北京车牌
            $qcp_a = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_qcp WHERE catid=8';
            $qcpa = \Phpcmf\Service::M()->db->query($qcp_a)->getResultArray();
            $qcpa_zs = (int)$qcpa[0]['numa']+$qcpa[0]['numb']+$qcpa[0]['numc']; //当前表总数
            $qcpa_zs_tit = (int)$qcpa[0]['numa']; //标题次数
            $qcpa_zs_key = (int)$qcpa[0]['numb']; //关键词次数
            $qcpa_zs_con = (int)$qcpa[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'qzcpzs'    => $qcpa_zs,
                'qzcpbt'    => $qcpa_zs_tit,
                'qzcpgjz'   => $qcpa_zs_key,
                'qzcpnr'    => $qcpa_zs_con,
            ]);

            //求租新能源车牌
            $qcp_b = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_qcp WHERE catid=9';
            $qcpb = \Phpcmf\Service::M()->db->query($qcp_b)->getResultArray();
            $qcpb_zs = (int)$qcpb[0]['numa']+$qcpb[0]['numb']+$qcpb[0]['numc']; //当前表总数
            $qcpb_zs_tit = (int)$qcpb[0]['numa']; //标题次数
            $qcpb_zs_key = (int)$qcpb[0]['numb']; //关键词次数
            $qcpb_zs_con = (int)$qcpb[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'xnyzs'    => $qcpb_zs,
                'xnybt'    => $qcpb_zs_tit,
                'xnygjc'   => $qcpb_zs_key,
                'xnynr'    => $qcpb_zs_con,
            ]);

            //求购京牌指标
            $qcp_c = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_qcp WHERE catid=10';
            $qcpc = \Phpcmf\Service::M()->db->query($qcp_c)->getResultArray();
            $qcpc_zs = (int)$qcpc[0]['numa']+$qcpc[0]['numb']+$qcpc[0]['numc']; //当前表总数
            $qcpc_zs_tit = (int)$qcpc[0]['numa']; //标题次数
            $qcpc_zs_key = (int)$qcpc[0]['numb']; //关键词次数
            $qcpc_zs_con = (int)$qcpc[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'jpzbzs'    => $qcpc_zs,
                'jpzbbt'    => $qcpc_zs_tit,
                'jpzbgjc'   => $qcpc_zs_key,
                'jpzbnr'    => $qcpc_zs_con,
            ]);

            //求北京车牌靓号
            $qcp_d = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_qcp WHERE catid=11';
            $qcpd = \Phpcmf\Service::M()->db->query($qcp_d)->getResultArray();
            $qcpd_zs = (int)$qcpd[0]['numa']+$qcpd[0]['numb']+$qcpd[0]['numc']; //当前表总数
            $qcpd_zs_tit = (int)$qcpd[0]['numa']; //标题次数
            $qcpd_zs_key = (int)$qcpd[0]['numb']; //关键词次数
            $qcpd_zs_con = (int)$qcpd[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'cpjhzs'    => $qcpd_zs,
                'cpjhbt'    => $qcpd_zs_tit,
                'cpjhgjz'   => $qcpd_zs_key,
                'cpjhnr'    => $qcpd_zs_con,
            ]);

            //wend统计
            $counts_wend = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_wend';
            $tabf = \Phpcmf\Service::M()->db->query($counts_wend)->getResultArray();
            $total_wend = (int)$tabf[0]['numa']+$tabf[0]['numb']+$tabf[0]['numc']; //当前表总数
            $total_wend_tit = (int)$tabf[0]['numa']; //标题次数
            $total_wend_key = (int)$tabf[0]['numb']; //关键词次数
            $total_wend_con = (int)$tabf[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'wdzcs'     => $total_wend,
                'wdbtcs'    => $total_wend_tit,
                'wdgjccs'   => $total_wend_key,
                'wdnrcs'    => $total_wend_con,
            ]);

            //求车牌号常见问答
            $wend_a = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_wend WHERE catid=22';
            $wd_a = \Phpcmf\Service::M()->db->query($wend_a)->getResultArray();
            $wenda_zs = (int)$wd_a[0]['numa']+$wd_a[0]['numb']+$wd_a[0]['numc']; //当前表总数
            $wenda_zs_tit = (int)$wd_a[0]['numa']; //标题次数
            $wenda_zs_key = (int)$wd_a[0]['numb']; //关键词次数
            $wenda_zs_con = (int)$wd_a[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'qpwdzs'    => $wenda_zs,
                'qpwdbt'    => $wenda_zs_tit,
                'qpwdgjz'   => $wenda_zs_key,
                'qpwdnr'    => $wenda_zs_con,
            ]);

            //京牌转让常见问题
            $wend_b = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_wend WHERE catid=23';
            $wd_b = \Phpcmf\Service::M()->db->query($wend_b)->getResultArray();
            $wendb_zs = (int)$wd_b[0]['numa']+$wd_b[0]['numb']+$wd_b[0]['numc']; //当前表总数
            $wendb_zs_tit = (int)$wd_b[0]['numa']; //标题次数
            $wendb_zs_key = (int)$wd_b[0]['numb']; //关键词次数
            $wendb_zs_con = (int)$wd_b[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zrwdzs'    => $wendb_zs,
                'zrwdbt'    => $wendb_zs_tit,
                'zrwdgjc'   => $wendb_zs_key,
                'zrwdnr'    => $wendb_zs_con,
            ]);

            //买车用车卖车答疑
            $wend_c = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_wend WHERE catid=24';
            $wd_c = \Phpcmf\Service::M()->db->query($wend_c)->getResultArray();
            $wendc_zs = (int)$wd_c[0]['numa']+$wd_c[0]['numb']+$wd_c[0]['numc']; //当前表总数
            $wendc_zs_tit = (int)$wd_c[0]['numa']; //标题次数
            $wendc_zs_key = (int)$wd_c[0]['numb']; //关键词次数
            $wendc_zs_con = (int)$wd_c[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'dyzss'    => $wendc_zs,
                'dayibt'    => $wendc_zs_tit,
                'dygjc'   => $wendc_zs_key,
                'dayinr'    => $wendc_zs_con,
            ]);

            //news统计
            $counts_news = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_news';
            $taba = \Phpcmf\Service::M()->db->query($counts_news)->getResultArray();
            $total_news = (int)$taba[0]['numa']+$taba[0]['numb']+$taba[0]['numc']; //总数
            $total_news_tit = (int)$taba[0]['numa']; //标题次数
            $total_news_key = (int)$taba[0]['numb']; //关键词次数
            $total_news_con = (int)$taba[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'bdzxzs'    => $total_news,
                'bdzxbtcs'  => $total_news_tit,
                'bdgjccs'   => $total_news_key,
                'bdnrcs'    => $total_news_con,
            ]);

            //车牌指标
            $news_a = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_news WHERE catid=25';
            $xw_a = \Phpcmf\Service::M()->db->query($news_a)->getResultArray();
            $newsa_zs = (int)$xw_a[0]['numa']+$xw_a[0]['numb']+$xw_a[0]['numc']; //总数
            $newsa_zs_tit = (int)$xw_a[0]['numa']; //标题次数
            $newsa_zs_key = (int)$xw_a[0]['numb']; //关键词次数
            $newsa_zs_con = (int)$xw_a[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'cpzbzs'    => $newsa_zs,
                'cpzbbt'  => $newsa_zs_tit,
                'cpzbgjc'   => $newsa_zs_key,
                'cpzbnr'    => $newsa_zs_con,
            ]);

            //汽车资讯
            $news_b = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_news WHERE catid=26';
            $xw_b = \Phpcmf\Service::M()->db->query($news_b)->getResultArray();
            $newsb_zs = (int)$xw_b[0]['numa']+$xw_b[0]['numb']+$xw_b[0]['numc']; //总数
            $newsb_zs_tit = (int)$xw_b[0]['numa']; //标题次数
            $newsb_zs_key = (int)$xw_b[0]['numb']; //关键词次数
            $newsb_zs_con = (int)$xw_b[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'qczxzs'    => $newsb_zs,
                'qczxbt'    => $newsb_zs_tit,
                'qczxgjc'   => $newsb_zs_key,
                'qczxnr'    => $newsb_zs_con,
            ]);

            //杂谈热点
            $news_c = 'SELECT '.$tit_num.' AS "numa" ,'.$key_num.' AS "numb" ,'.$des_num.' AS "numc" FROM dr_1_news WHERE catid=27';
            $xw_c = \Phpcmf\Service::M()->db->query($news_c)->getResultArray();
            $newsc_zs = (int)$xw_c[0]['numa']+$xw_c[0]['numb']+$xw_c[0]['numc']; //总数
            $newsc_zs_tit = (int)$xw_c[0]['numa']; //标题次数
            $newsc_zs_key = (int)$xw_c[0]['numb']; //关键词次数
            $newsc_zs_con = (int)$xw_c[0]['numc']; //内容次数
            //更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'ztrd'      => $newsc_zs,
                'ztrdbt'    => $newsc_zs_tit,
                'ztrdgjc'   => $newsc_zs_key,
                'ztrdnr'    => $newsc_zs_con,
            ]);

            //标签所有表 title、keywords、description、content 出现的总次数
            $tag_total = $total_news+$total_qcp+$total_zhuanr+$total_tix+$total_zhin+$total_wend;

            //所有表 title 中出现的次数
            $tit_total = $taba[0]['numa']+$tabb[0]['numa']+$tabc[0]['numa']+$tabd[0]['numa']+$tabe[0]['numa']+$tabf[0]['numa'];

            //所有表 keywords 中出现的次数
            $key_total = $taba[0]['numb']+$tabb[0]['numb']+$tabc[0]['numb']+$tabd[0]['numb']+$tabe[0]['numb']+$tabf[0]['numb'];

            //所有表 description 中出现的次数
            //$des_total = $taba[0]['numc']+$tabb[0]['numc']+$tabc[0]['numc']+$tabd[0]['numc']+$tabe[0]['numc']+$tabf[0]['numc'];

            //所有表 content 中出现的次数
            $con_total = $taba[0]['numc']+$tabb[0]['numc']+$tabc[0]['numc']+$tabd[0]['numc']+$tabe[0]['numc']+$tabf[0]['numc'];
            //更新
            $total_update = \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zongs'     => $tag_total,
                'titnum'    => $tit_total,
                'gjzzs'     => $key_total,
                //'mszs'      => $des_total,
                'nrzs'      => $con_total,
            ]);

            if($total_update){
                \Phpcmf\Service::M('cache')->sync_cache('tag', 'tag', 1);
            }
        }
        $this->_json(1, dr_lang('操作成功'));
    }
    public function ajaxnum(){
        $list_module = \Phpcmf\Service::L('cache')->get('module-'.SITE_ID.'-content');

        $dbprefix=\Phpcmf\Service::M()->db->DBPrefix; //数据库前缀
        $i = 0;
        $tag = \Phpcmf\Service::L('input')->get('name');
        $lanmu = '';
        $xiangguan = '';
        foreach($list_module as $t) {  //遍历所有模块
            $search_list = 'SELECT sum((LENGTH(`content`) - LENGTH(REPLACE(`content`,"'.$tag.'", ""))) / LENGTH("'.$tag.'")) AS "count" FROM '.$dbprefix.SITE_ID.'_'.$t['dirname'];
            $rt = \Phpcmf\Service::M()->db->query($search_list);
            if ($rt) {
                $rows = $rt->getResultArray();
                $i += (int)$rows[0]['count'];
                if($i > 0){
                    $lanmu .= '<li class="btn btn-secondary btn-sm" style="border: solid 1px #ccc;">'.$t['name'].'</li>';
                }else{
                    $lanmu = '暂无';
                }
            }
        }

        $data = array();
        $data['shuliang'] = $i;
        $data['lanmu'] =$lanmu;
        echo json_encode($data);//输出json数据
    }
    public function ajaxtag(){
        $str = '';
        $dbprefix=\Phpcmf\Service::M()->db->DBPrefix; //数据库前缀
        $id = \Phpcmf\Service::L('input')->get('id');
        $rt = \Phpcmf\Service::M()->db->query("select * from `dr_1_share_category` where id=".$id);
        if ($rt) {
            $row = $rt->getRowArray();
            $tag = \Phpcmf\Service::M()->db->query("select `name` from dr_1_tag");
            if ($tag) {
                $rows = $tag->getResultArray();
                foreach ($rows AS $key=>$val){
                    $search_list = 'SELECT sum((LENGTH(`content`) - LENGTH(REPLACE(`content`,"'.$val['name'].'", ""))) / LENGTH("'.$val['name'].'")) AS "count" FROM '.$dbprefix.SITE_ID.'_'.$row['mid'];
                    $rts = \Phpcmf\Service::M()->db->query($search_list);
                    if ($rts) {
                        $rowss = $rts->getResultArray();
                        if((int)$rowss[0]['count'] > 0){
                            $str .= '|'.$val['name'];
                        }
                    }
                }
            }
            $xiangguan = $str;
        }else{
            $xiangguan = 'ERROR';
        }
        $data = array();

        $data['xiangguan'] =$xiangguan;
        echo json_encode($data);//输出json数据
    }
    // 后台查看列表
    public function index() {

        list($tpl) = $this->_List();
        \Phpcmf\Service::V()->display($tpl);
    }

    // 后台批量添加内容
    public function all_add() {

        if (IS_AJAX_POST) {
            $rt = \Phpcmf\Service::M('Tag', 'tag')->save_all_data($this->pid, $_POST['all']);
            \Phpcmf\Service::M('cache')->sync_cache('tag', 'tag', 1);
            $this->_json($rt['code'], $rt['msg']);
        }

        \Phpcmf\Service::V()->assign([
            'form' => dr_form_hidden(),
            'reply_url' =>\Phpcmf\Service::L('Router')->get_back(\Phpcmf\Service::L('Router')->uri('index')),
        ]);

        \Phpcmf\Service::V()->display('tag_all.html');
    }

    // 后台添加内容
    public function add() {
        list($tpl) = $this->_Post(0);
        \Phpcmf\Service::V()->assign([
            'form' => dr_form_hidden(),
        ]);
        \Phpcmf\Service::V()->display($tpl);exit;
    }


    // 后台修改内容
    public function edit() {
        //内容id
        $tagid =  \Phpcmf\Service::L('Input')->get('id');
        list($tpl) = $this->_Post(intval($tagid));

        //标签名称
        $tag_title = \Phpcmf\Service::M()->table(SITE_ID.'_tag')->where('id',$tagid)->getRow();

        //标签名称
        $tagName = trim($tag_title['name']);

        //相关词
        $xgc = \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where(' name LIKE "%'.$tagName.'%"')->get();
        $rowss = $xgc->getResultArray();

        \Phpcmf\Service::V()->assign([
            'form'          => dr_form_hidden(),
            'bqlist'        => $rowss,      //相关词
        ]);
        \Phpcmf\Service::V()->display($tpl);exit;
    }

    // 后台批量保存排序值
    public function order_edit() {
        $this->_Display_Order(
            intval(\Phpcmf\Service::L('Input')->get('id')),
            intval(\Phpcmf\Service::L('Input')->get('value')),
            function ($r) {
                \Phpcmf\Service::M('cache')->sync_cache('tag', 'tag', 1);
            }
        );
    }

    // 后台删除内容
    public function del() {
        $this->_Del(
            \Phpcmf\Service::L('Input')->get_post_ids(),
            null,
            function ($r) {
                \Phpcmf\Service::M('cache')->sync_cache('tag', 'tag', 1);
            },
            \Phpcmf\Service::M()->dbprefix($this->init['table'])
        );
    }

    // ===========================

    /**
     * 保存内容
     * $id      内容id,新增为0
     * $data    提交内容数组,留空为自动获取
     * $func    格式化提交的数据
     * */
    protected function _Save($id = 0, $data = [], $old = [], $func = null, $func2 = null) {

        return parent::_Save($id, $data, $old,
            function ($id, $data, $old) {
                // 提交之前的判断
                $post = \Phpcmf\Service::L('Input')->post('data');
                if (\Phpcmf\Service::M('Tag', 'tag')->check_code($id, $post['code'])) {
                    return dr_return_data(0, dr_lang('别名已经存在'));
                } elseif (\Phpcmf\Service::M('Tag', 'tag')->check_name($id, $post['name'])) {
                    return dr_return_data(0, dr_lang('tag名称已经存在'));
                }
                $data[1]['pid'] = $old ? $old['pid'] : $this->pid;
                !$old && $data[1]['childids'] = ''; // 初始化字段
                $data[1]['code'] = $post['code'];
                $data[1]['hits'] = intval($post['hits']);
                !$data[1]['content'] && $data[1]['content'] = '';
                return dr_return_data(1, 'ok', $data);
            },
            function ($id, $data, $old) {
                // 提交之后
                $data[1]['pcode'] = \Phpcmf\Service::M('Tag', 'tag')->get_pcode($data[1]);
                // 更新
                \Phpcmf\Service::M('Tag', 'tag')->save_data($id, array(
                    'pcode' => $data[1]['pcode'],
                ));
                if ($data[1]['pid']) {
                    // 标记存在子菜单
                    \Phpcmf\Service::M()->table(SITE_ID.'_tag')->update($data[1]['pid'], array(
                        'childids' => 1,
                    ));
                }

                \Phpcmf\Service::M('cache')->sync_cache('tag', 'tag', 1);
                return $data;
            }
        );
    }

    // 后台批量移动栏目
    public function move_edit() {

        $ids = \Phpcmf\Service::L('input')->get_post_ids();
        if (!$ids) {
            $this->_json(0, dr_lang('所选tag不存在'));
        }
        // 批量更换栏目
        \Phpcmf\Service::M()->db->table($this->init['table'])->whereIn('id', $ids)->update(['type' => $_POST['type']]);

        // 自动更新缓存
        \Phpcmf\Service::M('cache')->sync_cache();
        $this->_json(1, dr_lang('操作成功'));
    }
    
}
