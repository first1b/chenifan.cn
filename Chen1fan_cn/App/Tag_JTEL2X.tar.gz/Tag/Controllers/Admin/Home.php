<?php namespace Phpcmf\Controllers\Admin;


// 内容模块tag操作类 基于 Ftable
class Home extends \Phpcmf\Table
{
    public $pid;

    public function __construct(...$params) {
        parent::__construct(...$params);
        // 支持附表存储
        $this->is_data = 0;
        // 模板前缀(避免混淆)
        $this->tpl_prefix = 'tag_';
        // 单独模板命名
        $this->tpl_name = 'tag_content';
        // 模块显示名称
        $this->name = dr_lang('Tag');
        // pid
        $this->pid = intval(\Phpcmf\Service::L('input')->get('pid'));
        $myfield = [
            'name' => [
                'ismain' => 1,
                'name' => dr_lang('名称'),
                'fieldname' => 'name',
                'fieldtype' => 'Text',
                'setting' => array(
                    'option' => array(
                        'width' => 200,
                    ),
                    'is_right' => 2,
                )
            ],
            'displayorder' => array(
                'name' => dr_lang('权重值'),
                'ismain' => 1,
                'fieldtype' => 'Touchspin',
                'fieldname' => 'displayorder',
                'setting' => array(
                    'option' => array(
                        'width' => 200,
                        'max' => '999999999',
                        'min' => '0',
                        'step' => '1',
                        'show' => '1',
                        'value' => 0
                    ),
                    'validate' => array(
                        'tips' => dr_lang('权重值越高排列越靠前'),
                    )
                )
            ),
            'content' => [
                'ismain' => 1,
                'name' => dr_lang('描述信息'),
                'fieldname' => 'content',
                'fieldtype' => 'Ueditor',
                'setting' => array(
                    'option' => array(
                        'mode' => 1,
                        'height' => 300,
                        'width' => '100%',
                    ),
                )
            ],
        ];
        // 初始化数据表
        $this->_init([
            'table' => SITE_ID.'_tag',
            'field' => dr_array22array($myfield, \Phpcmf\Service::L('cache')->get('tag-'.SITE_ID.'-field')),
            'show_field' => 'name',
            'sys_field' => ['content'],
            'where_list' => 'pid='.$this->pid,
            'order_by' => 'displayorder DESC,id ASC',
        ]);
        \Phpcmf\Service::V()->assign([
            'pid' => $this->pid,
            'menu' => \Phpcmf\Service::M('auth')->_admin_menu(
                [
                    '关键词' => [APP_DIR.'/'.\Phpcmf\Service::L('Router')->class.'/index', 'fa fa-tag'],
                    '添加' => [APP_DIR.'/'.\Phpcmf\Service::L('Router')->class.'/add', 'fa fa-plus'],
                    '修改' => ['hide:'.APP_DIR.'/'.\Phpcmf\Service::L('Router')->class.'/edit', 'fa fa-edit'],
                    '批量添加' => [APP_DIR.'/'.\Phpcmf\Service::L('Router')->class.'/all_add', 'fa fa-plus-square-o'],
                    '自定义字段' => ['url:'.\Phpcmf\Service::L('Router')->url('field/index', ['rname' => 'tag', 'rid'=>SITE_ID]), 'fa fa-code'],
                    'help' => [63]
                ]
            ),
            'field' => $this->init['field'],
        ]);
    }
    public function zts(){
        $rt = \Phpcmf\Service::M()->db->query("select `id` from dr_1_tag");
        $rows = $rt->getResultArray();
        $this->_json(1, count($rows));
    }


    // ========================
    public function gengxin(){
        $i = (int)\Phpcmf\Service::L('input')->get('num');
        $is = $i*10;

        $rt = \Phpcmf\Service::M()->db->query("select `id`,`name` from dr_1_tag limit ".$is.",10");

        $rows = $rt->getResultArray();

        foreach ($rows AS $key=>$val){
            //标签名称
            $tag_title = \Phpcmf\Service::M()->table(SITE_ID.'_tag')->where('id',$val['id'])->getRow();

            //标签名称
            $tagName = trim($tag_title['name']);

            //相关词数量
            $sqlxg = 'SELECT `id` FROM dr_1_tag AS a WHERE a.name LIKE "%'.$tagName.'%"';
            $xgcnum = \Phpcmf\Service::M()->db->query($sqlxg)->getResultArray();
            //相关词数量更新
            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'xgcsl'    => count($xgcnum),
            ]);

            $cun = ' count(*) AS b '; //统计字段
            $fieldQuery = ' (title LIKE "%'.$tagName.'%" OR keywords LIKE "%'.$tagName.'%" OR description LIKE "%'.$tagName.'%")';  //查询所有字段
            $fieldTit = ' (title LIKE "%'.$tagName.'%")';  //查询标题字段
            $fieldKey = ' (keywords LIKE "%'.$tagName.'%")';  //查询关键词字段
            $fieldDes = ' (description LIKE "%'.$tagName.'%")';  //查询描述字段
            /*
                        * $tag_title $tagName $sqlxg $xgcnum $cun $fieldQuery $fieldTit $fieldKey $fieldDes $counta $countb $countc $countd $counte $countf
                        */
            //统计的表
            $counta = ' SELECT '.$cun.' FROM dr_1_tix WHERE '.$fieldQuery.''; //提醒
            $countb = ' SELECT '.$cun.' FROM dr_1_zhin WHERE '.$fieldQuery.''; //指南
            $countc = ' SELECT '.$cun.' FROM dr_1_zhuanr WHERE '.$fieldQuery.''; //求车牌
            $countd = ' SELECT '.$cun.' FROM dr_1_qcp WHERE '.$fieldQuery.''; //转让
            $counte = ' SELECT '.$cun.' FROM dr_1_wend WHERE '.$fieldQuery.''; //问答
            $countf = ' SELECT '.$cun.' FROM dr_1_news WHERE '.$fieldQuery.''; //资讯
            //标题
            $cou_ta = ' SELECT '.$cun.' FROM dr_1_tix WHERE '.$fieldTit.''; //提醒
            $cou_tb = ' SELECT '.$cun.' FROM dr_1_zhin WHERE '.$fieldTit.''; //指南
            $cou_tc = ' SELECT '.$cun.' FROM dr_1_zhuanr WHERE '.$fieldTit.''; //求车牌
            $cou_td = ' SELECT '.$cun.' FROM dr_1_qcp WHERE '.$fieldTit.''; //转让
            $cou_te = ' SELECT '.$cun.' FROM dr_1_wend WHERE '.$fieldTit.''; //问答
            $cou_tf = ' SELECT '.$cun.' FROM dr_1_news WHERE '.$fieldTit.''; //资讯
            //关键词
            $cou_ka = ' SELECT '.$cun.' FROM dr_1_tix WHERE '.$fieldKey.''; //提醒
            $cou_kb = ' SELECT '.$cun.' FROM dr_1_zhin WHERE '.$fieldKey.''; //指南
            $cou_kc = ' SELECT '.$cun.' FROM dr_1_zhuanr WHERE '.$fieldKey.''; //求车牌
            $cou_kd = ' SELECT '.$cun.' FROM dr_1_qcp WHERE '.$fieldKey.''; //转让
            $cou_ke = ' SELECT '.$cun.' FROM dr_1_wend WHERE '.$fieldKey.''; //问答
            $cou_kf = ' SELECT '.$cun.' FROM dr_1_news WHERE '.$fieldKey.''; //资讯
            //描述
            $cou_da = ' SELECT '.$cun.' FROM dr_1_tix WHERE '.$fieldDes.''; //提醒
            $cou_db = ' SELECT '.$cun.' FROM dr_1_zhin WHERE '.$fieldDes.''; //指南
            $cou_dc = ' SELECT '.$cun.' FROM dr_1_zhuanr WHERE '.$fieldDes.''; //求车牌
            $cou_dd = ' SELECT '.$cun.' FROM dr_1_qcp WHERE '.$fieldDes.''; //转让
            $cou_de = ' SELECT '.$cun.' FROM dr_1_wend WHERE '.$fieldDes.''; //问答
            $cou_df = ' SELECT '.$cun.' FROM dr_1_news WHERE '.$fieldDes.''; //资讯

            //全部统计
            $allnum = 'SELECT SUM(b) AS tjall FROM(' . $counta . ' UNION ALL ' . $countb . ' UNION ALL ' . $countc . ' UNION ALL ' . $countd . ' UNION ALL ' . $counte . ' UNION ALL ' . $countf . ') AS a';
            $alltit = 'SELECT SUM(b) AS tjall FROM(' . $cou_ta . ' UNION ALL ' . $cou_tb . ' UNION ALL ' . $cou_tc . ' UNION ALL ' . $cou_td . ' UNION ALL ' . $cou_te . ' UNION ALL ' . $cou_tf . ') AS a';
            $allkey = 'SELECT SUM(b) AS tjall FROM(' . $cou_ka . ' UNION ALL ' . $cou_kb . ' UNION ALL ' . $cou_kc . ' UNION ALL ' . $cou_kd . ' UNION ALL ' . $cou_ke . ' UNION ALL ' . $cou_kf . ') AS a';
            $alldes = 'SELECT SUM(b) AS tjall FROM(' . $cou_da . ' UNION ALL ' . $cou_db . ' UNION ALL ' . $cou_dc . ' UNION ALL ' . $cou_dd . ' UNION ALL ' . $cou_de . ' UNION ALL ' . $cou_df . ') AS a';


            //记录总数
            $list_total = \Phpcmf\Service::M()->db->query($allnum)->getResultArray();
            $total_nums = $list_total[0]['tjall'];

            $list_total_title = \Phpcmf\Service::M()->db->query($alltit)->getResultArray();
            $total_nums_title = $list_total_title[0]['tjall'];

            $list_total_key = \Phpcmf\Service::M()->db->query($allkey)->getResultArray();
            $total_nums_key = $list_total_key[0]['tjall'];

            $list_total_des = \Phpcmf\Service::M()->db->query($alldes)->getResultArray();
            $total_nums_des = $list_total_des[0]['tjall'];

            //全部更新
            $total_update = \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zongs'     => $total_nums,
                'titnum'    => $total_nums_title,
                'gjzzs'     => $total_nums_key,
                'nrzs'      => $total_nums_des,
            ]);


            //提醒
            $txnum = 'SELECT SUM(b) AS tjall FROM(' . $counta . ') AS a';
            $list_total_tx = \Phpcmf\Service::M()->db->query($txnum)->getResultArray();
            $total_nums_tx = $list_total_tx[0]['tjall'];

            $txnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_ta . ') AS a';
            $list_total_tx_t = \Phpcmf\Service::M()->db->query($txnum_t)->getResultArray();
            $total_nums_tx_t = $list_total_tx_t[0]['tjall'];

            $txnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_ka . ') AS a';
            $list_total_tx_k = \Phpcmf\Service::M()->db->query($txnum_k)->getResultArray();
            $total_nums_tx_k = $list_total_tx_k[0]['tjall'];

            $txnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_da . ') AS a';
            $list_total_tx_d = \Phpcmf\Service::M()->db->query($txnum_d)->getResultArray();
            $total_nums_tx_d = $list_total_tx_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'txzcs'     => $total_nums_tx,
                'txbtcs'    => $total_nums_tx_t,
                'txgjccs'   => $total_nums_tx_k,
                'txnrcs'    => $total_nums_tx_d,
            ]);

            //求车牌号注意事项
            $txanum = 'SELECT SUM(b) AS tjall FROM(' . $counta . ' AND catid=16 ) AS a';
            $list_total_txa = \Phpcmf\Service::M()->db->query($txanum)->getResultArray();
            $total_nums_txa = $list_total_txa[0]['tjall'];

            $txanum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_ta . ' AND catid=16 ) AS a';
            $list_total_txa_t = \Phpcmf\Service::M()->db->query($txanum_t)->getResultArray();
            $total_nums_txa_t = $list_total_txa_t[0]['tjall'];

            $txanum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_ka . ' AND catid=16 ) AS a';
            $list_total_txa_k = \Phpcmf\Service::M()->db->query($txanum_k)->getResultArray();
            $total_nums_txa_k = $list_total_txa_k[0]['tjall'];

            $txanum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_da . ' AND catid=16 ) AS a';
            $list_total_txa_d = \Phpcmf\Service::M()->db->query($txanum_d)->getResultArray();
            $total_nums_txa_d = $list_total_txa_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'qpzyzs'    => $total_nums_txa,
                'qpzybt'    => $total_nums_txa_t,
                'qpzygjc'   => $total_nums_txa_k,
                'qpzynr'    => $total_nums_txa_d,
            ]);

            //京牌转让注意事项
            $txbnum = 'SELECT SUM(b) AS tjall FROM(' . $counta . ' AND catid=17 ) AS a';
            $list_total_txb = \Phpcmf\Service::M()->db->query($txbnum)->getResultArray();
            $total_nums_txb = $list_total_txb[0]['tjall'];

            $txbnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_ta . ' AND catid=17 ) AS a';
            $list_total_txb_t = \Phpcmf\Service::M()->db->query($txbnum_t)->getResultArray();
            $total_nums_txb_t = $list_total_txb_t[0]['tjall'];

            $txbnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_ka . ' AND catid=17 ) AS a';
            $list_total_txb_k = \Phpcmf\Service::M()->db->query($txbnum_k)->getResultArray();
            $total_nums_txb_k = $list_total_txb_k[0]['tjall'];

            $txbnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_da . ' AND catid=17 ) AS a';
            $list_total_txb_d = \Phpcmf\Service::M()->db->query($txbnum_d)->getResultArray();
            $total_nums_txb_d = $list_total_txb_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zrzyzs'    => $total_nums_txb,
                'zrzybt'    => $total_nums_txb_t,
                'zrzygjz'   => $total_nums_txb_k,
                'zrzynr'    => $total_nums_txb_d,
            ]);

            //买车用车卖车提醒
            $txcnum = 'SELECT SUM(b) AS tjall FROM(' . $counta . ' AND catid=18 ) AS a';
            $list_total_txc = \Phpcmf\Service::M()->db->query($txcnum)->getResultArray();
            $total_nums_txc = $list_total_txc[0]['tjall'];

            $txcnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_ta . ' AND catid=18 ) AS a';
            $list_total_txc_t = \Phpcmf\Service::M()->db->query($txcnum_t)->getResultArray();
            $total_nums_txc_t = $list_total_txc_t[0]['tjall'];

            $txcnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_ka . ' AND catid=18 ) AS a';
            $list_total_txc_k = \Phpcmf\Service::M()->db->query($txcnum_k)->getResultArray();
            $total_nums_txc_k = $list_total_txc_k[0]['tjall'];

            $txcnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_da . ' AND catid=18 ) AS a';
            $list_total_txc_d = \Phpcmf\Service::M()->db->query($txcnum_d)->getResultArray();
            $total_nums_txc_d = $list_total_txc_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'myctxzs'    => $total_nums_txc,
                'myctxbt'    => $total_nums_txc_t,
                'myctxgjc'   => $total_nums_txc_k,
                'myctxnr'    => $total_nums_txc_d,
            ]);

            //指南
            $znnum = 'SELECT SUM(b) AS tjall FROM(' . $countb . ') AS a';
            $list_total_zn = \Phpcmf\Service::M()->db->query($znnum)->getResultArray();
            $total_nums_zn = $list_total_zn[0]['tjall'];

            $znnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tb . ') AS a';
            $list_total_zn_t = \Phpcmf\Service::M()->db->query($znnum_t)->getResultArray();
            $total_nums_zn_t = $list_total_zn_t[0]['tjall'];

            $znnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kb . ') AS a';
            $list_total_zn_k = \Phpcmf\Service::M()->db->query($znnum_k)->getResultArray();
            $total_nums_zn_k = $list_total_zn_k[0]['tjall'];

            $znnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_db . ') AS a';
            $list_total_zn_d = \Phpcmf\Service::M()->db->query($znnum_d)->getResultArray();
            $total_nums_zn_d = $list_total_zn_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'znzcs'     => $total_nums_zn,
                'znbtcs'    => $total_nums_zn_t,
                'zngjccs'   => $total_nums_zn_k,
                'znnrcs'    => $total_nums_zn_d,
            ]);

            //北京车牌办理指南
            $znanum = 'SELECT SUM(b) AS tjall FROM(' . $countb . ' AND catid=19 ) AS a';
            $list_total_zna = \Phpcmf\Service::M()->db->query($znanum)->getResultArray();
            $total_nums_zna = $list_total_zna[0]['tjall'];

            $znanum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tb . ' AND catid=19 ) AS a';
            $list_total_zna_t = \Phpcmf\Service::M()->db->query($znanum_t)->getResultArray();
            $total_nums_zna_t = $list_total_zna_t[0]['tjall'];

            $znanum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kb . ' AND catid=19 ) AS a';
            $list_total_zna_k = \Phpcmf\Service::M()->db->query($znanum_k)->getResultArray();
            $total_nums_zna_k = $list_total_zna_k[0]['tjall'];

            $znanum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_db . ' AND catid=19 ) AS a';
            $list_total_zna_d = \Phpcmf\Service::M()->db->query($znanum_d)->getResultArray();
            $total_nums_zna_d = $list_total_zna_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'blznzs'    => $total_nums_zna,
                'blznbt'    => $total_nums_zna_t,
                'blzngjc'   => $total_nums_zna_k,
                'blznnr'    => $total_nums_zna_d,
            ]);

            //北京车牌转让技巧
            $znbnum = 'SELECT SUM(b) AS tjall FROM(' . $countb . ' AND catid=20 ) AS a';
            $list_total_znb = \Phpcmf\Service::M()->db->query($znbnum)->getResultArray();
            $total_nums_znb = $list_total_znb[0]['tjall'];

            $znbnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tb . ' AND catid=20 ) AS a';
            $list_total_znb_t = \Phpcmf\Service::M()->db->query($znbnum_t)->getResultArray();
            $total_nums_znb_t = $list_total_znb_t[0]['tjall'];

            $znbnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kb . ' AND catid=20 ) AS a';
            $list_total_znb_k = \Phpcmf\Service::M()->db->query($znbnum_k)->getResultArray();
            $total_nums_znb_k = $list_total_znb_k[0]['tjall'];

            $znbnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_db . ' AND catid=20 ) AS a';
            $list_total_znb_d = \Phpcmf\Service::M()->db->query($znbnum_d)->getResultArray();
            $total_nums_znb_d = $list_total_znb_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zrjqzs'    => $total_nums_znb,
                'zrjqbt'    => $total_nums_znb_t,
                'zrjqgjz'   => $total_nums_znb_k,
                'zrjqnr'    => $total_nums_znb_d,
            ]);

            //买车用车卖车技巧
            $zncnum = 'SELECT SUM(b) AS tjall FROM(' . $countb . ' AND catid=21 ) AS a';
            $list_total_znc = \Phpcmf\Service::M()->db->query($zncnum)->getResultArray();
            $total_nums_znc = $list_total_znc[0]['tjall'];

            $zncnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tb . ' AND catid=21 ) AS a';
            $list_total_znc_t = \Phpcmf\Service::M()->db->query($zncnum_t)->getResultArray();
            $total_nums_zncc_t = $list_total_znc_t[0]['tjall'];

            $zncnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kb . ' AND catid=21 ) AS a';
            $list_total_znc_k = \Phpcmf\Service::M()->db->query($zncnum_k)->getResultArray();
            $total_nums_znc_k = $list_total_znc_k[0]['tjall'];

            $zncnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_db . ' AND catid=21 ) AS a';
            $list_total_znc_d = \Phpcmf\Service::M()->db->query($zncnum_d)->getResultArray();
            $total_nums_znc_d = $list_total_znc_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'mcjqzs'    => $total_nums_znc,
                'mcjqbt'    => $total_nums_zncc_t,
                'mcjqgjz'   => $total_nums_znc_k,
                'mcjqnr'    => $total_nums_znc_d,
            ]);

            //求牌
            $qpnum = 'SELECT SUM(b) AS tjall FROM(' . $countc . ') AS a';
            $list_total_qp = \Phpcmf\Service::M()->db->query($qpnum)->getResultArray();
            $total_nums_qp = $list_total_qp[0]['tjall'];

            $qpnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tc . ') AS a';
            $list_total_qp_t = \Phpcmf\Service::M()->db->query($qpnum_t)->getResultArray();
            $total_nums_qp_t = $list_total_qp_t[0]['tjall'];

            $qpnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kc . ') AS a';
            $list_total_qp_k = \Phpcmf\Service::M()->db->query($qpnum_k)->getResultArray();
            $total_nums_qp_k = $list_total_qp_k[0]['tjall'];

            $qpnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_dc . ') AS a';
            $list_total_qp_d = \Phpcmf\Service::M()->db->query($qpnum_d)->getResultArray();
            $total_nums_qp_d = $list_total_qp_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'qcpzcs'     => $total_nums_qp,
                'qcpbtcs'    => $total_nums_qp_t,
                'qcpgjccs'   => $total_nums_qp_k,
                'qcpnrcs'    => $total_nums_qp_d,
            ]);

            //小汽车指标出租
            $qpanum = 'SELECT SUM(b) AS tjall FROM(' . $countc . ' AND catid=12 ) AS a';
            $list_total_qpa = \Phpcmf\Service::M()->db->query($qpanum)->getResultArray();
            $total_nums_qpa = $list_total_qpa[0]['tjall'];

            $qpanum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tc . ' AND catid=12 ) AS a';
            $list_total_qpa_t = \Phpcmf\Service::M()->db->query($qpanum_t)->getResultArray();
            $total_nums_qpa_t = $list_total_qpa_t[0]['tjall'];

            $qpanum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kc . ' AND catid=12 ) AS a';
            $list_total_qpa_k = \Phpcmf\Service::M()->db->query($qpanum_k)->getResultArray();
            $total_nums_qpa_k = $list_total_qpa_k[0]['tjall'];

            $qpanum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_dc . ' AND catid=12 ) AS a';
            $list_total_qpa_d = \Phpcmf\Service::M()->db->query($qpanum_d)->getResultArray();
            $total_nums_qpa_d = $list_total_qpa_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zbczzs'    => $total_nums_qpa,
                'zbczbt'    => $total_nums_qpa_t,
                'zbczgjc'   => $total_nums_qpa_k,
                'zbcznr'    => $total_nums_qpa_d,
            ]);

            //新能源车牌出租
            $qpbnum = 'SELECT SUM(b) AS tjall FROM(' . $countc . ' AND catid=13 ) AS a';
            $list_total_qpb = \Phpcmf\Service::M()->db->query($qpbnum)->getResultArray();
            $total_nums_qpb = $list_total_qpb[0]['tjall'];

            $qpbnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tc . ' AND catid=13 ) AS a';
            $list_total_qpb_t = \Phpcmf\Service::M()->db->query($qpbnum_t)->getResultArray();
            $total_nums_qpb_t = $list_total_qpb_t[0]['tjall'];

            $qpbnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kc . ' AND catid=13 ) AS a';
            $list_total_qpb_k = \Phpcmf\Service::M()->db->query($qpbnum_k)->getResultArray();
            $total_nums_qpb_k = $list_total_qpb_k[0]['tjall'];

            $qpbnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_dc . ' AND catid=13 ) AS a';
            $list_total_qpb_d = \Phpcmf\Service::M()->db->query($qpbnum_d)->getResultArray();
            $total_nums_qpb_d = $list_total_qpb_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'cpczzs'    => $total_nums_qpb,
                'cpczbt'    => $total_nums_qpb_t,
                'cpczgjz'   => $total_nums_qpb_k,
                'cpcznr'    => $total_nums_qpb_d,
            ]);

            //北京车牌出售
            $qpcnum = 'SELECT SUM(b) AS tjall FROM(' . $countc . ' AND catid=14 ) AS a';
            $list_total_qpc = \Phpcmf\Service::M()->db->query($qpcnum)->getResultArray();
            $total_nums_qpc = $list_total_qpc[0]['tjall'];

            $qpcnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tc . ' AND catid=14 ) AS a';
            $list_total_qpc_t = \Phpcmf\Service::M()->db->query($qpcnum_t)->getResultArray();
            $total_nums_qpc_t = $list_total_qpc_t[0]['tjall'];

            $qpcnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kc . ' AND catid=14 ) AS a';
            $list_total_qpc_k = \Phpcmf\Service::M()->db->query($qpcnum_k)->getResultArray();
            $total_nums_qpc_k = $list_total_qpc_k[0]['tjall'];

            $qpcnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_dc . ' AND catid=14 ) AS a';
            $list_total_qpc_d = \Phpcmf\Service::M()->db->query($qpcnum_d)->getResultArray();
            $total_nums_qpc_d = $list_total_qpc_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'cpcszs'    => $total_nums_qpc,
                'cpcsbt'    => $total_nums_qpc_t,
                'cpcsgjc'   => $total_nums_qpc_k,
                'cpcsnr'    => $total_nums_qpc_d,
            ]);


            //靓号车牌转让
            $qpdnum = 'SELECT SUM(b) AS tjall FROM(' . $countc . ' AND catid=15 ) AS a';
            $list_total_qpd = \Phpcmf\Service::M()->db->query($qpdnum)->getResultArray();
            $total_nums_qpd = $list_total_qpd[0]['tjall'];

            $qpdnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tc . ' AND catid=15 ) AS a';
            $list_total_qpd_t = \Phpcmf\Service::M()->db->query($qpdnum_t)->getResultArray();
            $total_nums_qpd_t = $list_total_qpd_t[0]['tjall'];

            $qpdnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kc . ' AND catid=15 ) AS a';
            $list_total_qpd_k = \Phpcmf\Service::M()->db->query($qpdnum_k)->getResultArray();
            $total_nums_qpd_k = $list_total_qpd_k[0]['tjall'];

            $qpdnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_dc . ' AND catid=15 ) AS a';
            $list_total_qpd_d = \Phpcmf\Service::M()->db->query($qpdnum_d)->getResultArray();
            $total_nums_qpd_d = $list_total_qpd_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'cpzrzs'    => $total_nums_qpd,
                'cpzrbt'    => $total_nums_qpd_t,
                'cpzrgjc'   => $total_nums_qpd_k,
                'cpzrnr'    => $total_nums_qpd_d,
            ]);


            //转让
            $zr = 'SELECT SUM(b) AS tjall FROM(' . $countd . ') AS a';
            $list_total_zr = \Phpcmf\Service::M()->db->query($zr)->getResultArray();
            $total_nums_zr = $list_total_zr[0]['tjall'];

            $zrnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_td . ') AS a';
            $list_total_zr_t = \Phpcmf\Service::M()->db->query($zrnum_t)->getResultArray();
            $total_nums_zr_t = $list_total_zr_t[0]['tjall'];

            $zrnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kd . ') AS a';
            $list_total_zr_k = \Phpcmf\Service::M()->db->query($zrnum_k)->getResultArray();
            $total_nums_zr_k = $list_total_zr_k[0]['tjall'];

            $zrnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_dd . ') AS a';
            $list_total_zr_d = \Phpcmf\Service::M()->db->query($zrnum_d)->getResultArray();
            $total_nums_zr_d = $list_total_zr_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zrzcs'     => $total_nums_zr,
                'zrbtcs'    => $total_nums_zr_t,
                'zrgjccs'   => $total_nums_zr_k,
                'zrnrcs'    => $total_nums_zr_d,
            ]);

            //求租北京车牌
            $zra = 'SELECT SUM(b) AS tjall FROM(' . $countd . ' AND catid=8 ) AS a';
            $list_total_zra = \Phpcmf\Service::M()->db->query($zra)->getResultArray();
            $total_nums_zra = $list_total_zra[0]['tjall'];

            $zranum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_td . ' AND catid=8 ) AS a';
            $list_total_zra_t = \Phpcmf\Service::M()->db->query($zranum_t)->getResultArray();
            $total_nums_zra_t = $list_total_zra_t[0]['tjall'];

            $zranum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kd . ' AND catid=8 ) AS a';
            $list_total_zra_k = \Phpcmf\Service::M()->db->query($zranum_k)->getResultArray();
            $total_nums_zra_k = $list_total_zra_k[0]['tjall'];

            $zranum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_dd . ' AND catid=8 ) AS a';
            $list_total_zra_d = \Phpcmf\Service::M()->db->query($zranum_d)->getResultArray();
            $total_nums_zra_d = $list_total_zra_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'qzcpzs'    => $total_nums_zra,
                'qzcpbt'    => $total_nums_zra_t,
                'qzcpgjz'   => $total_nums_zra_k,
                'qzcpnr'    => $total_nums_zra_d,
            ]);

            //求租新能源车牌
            $zrb = 'SELECT SUM(b) AS tjall FROM(' . $countd . ' AND catid=9 ) AS a';
            $list_total_zrb = \Phpcmf\Service::M()->db->query($zrb)->getResultArray();
            $total_nums_zrb = $list_total_zrb[0]['tjall'];

            $zrbnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_td . ' AND catid=9 ) AS a';
            $list_total_zrb_t = \Phpcmf\Service::M()->db->query($zrbnum_t)->getResultArray();
            $total_nums_zrb_t = $list_total_zrb_t[0]['tjall'];

            $zrbnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kd . ' AND catid=9 ) AS a';
            $list_total_zrb_k = \Phpcmf\Service::M()->db->query($zrbnum_k)->getResultArray();
            $total_nums_zrb_k = $list_total_zrb_k[0]['tjall'];

            $zrbnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_dd . ' AND catid=9 ) AS a';
            $list_total_zrb_d = \Phpcmf\Service::M()->db->query($zrbnum_d)->getResultArray();
            $total_nums_zrb_d = $list_total_zrb_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'xnyzs'    => $total_nums_zrb,
                'xnybt'    => $total_nums_zrb_t,
                'xnygjc'   => $total_nums_zrb_k,
                'xnynr'    => $total_nums_zrb_d,
            ]);

            //求购京牌指标
            $zrc = 'SELECT SUM(b) AS tjall FROM(' . $countd . ' AND catid=10 ) AS a';
            $list_total_zrc = \Phpcmf\Service::M()->db->query($zrc)->getResultArray();
            $total_nums_zrc = $list_total_zrc[0]['tjall'];

            $zrcnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_td . ' AND catid=10 ) AS a';
            $list_total_zrc_t = \Phpcmf\Service::M()->db->query($zrcnum_t)->getResultArray();
            $total_nums_zrc_t = $list_total_zrc_t[0]['tjall'];

            $zrcnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kd . ' AND catid=10 ) AS a';
            $list_total_zrc_k = \Phpcmf\Service::M()->db->query($zrcnum_k)->getResultArray();
            $total_nums_zrc_k = $list_total_zrc_k[0]['tjall'];

            $zrcnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_dd . ' AND catid=10 ) AS a';
            $list_total_zrc_d = \Phpcmf\Service::M()->db->query($zrcnum_d)->getResultArray();
            $total_nums_zrc_d = $list_total_zrc_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'jpzbzs'    => $total_nums_zrc,
                'jpzbbt'    => $total_nums_zrc_t,
                'jpzbgjc'   => $total_nums_zrc_k,
                'jpzbnr'    => $total_nums_zrc_d,
            ]);

            //求北京车牌靓号
            $zrd = 'SELECT SUM(b) AS tjall FROM(' . $countd . ' AND catid=11 ) AS a';
            $list_total_zrd = \Phpcmf\Service::M()->db->query($zrd)->getResultArray();
            $total_nums_zrd = $list_total_zrd[0]['tjall'];

            $zrdnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_td . ' AND catid=11 ) AS a';
            $list_total_zrd_t = \Phpcmf\Service::M()->db->query($zrdnum_t)->getResultArray();
            $total_nums_zrd_t = $list_total_zrd_t[0]['tjall'];

            $zrdnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kd . ' AND catid=11 ) AS a';
            $list_total_zrd_k = \Phpcmf\Service::M()->db->query($zrdnum_k)->getResultArray();
            $total_nums_zrd_k = $list_total_zrd_k[0]['tjall'];

            $zrdnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_dd . ' AND catid=11 ) AS a';
            $list_total_zrd_d = \Phpcmf\Service::M()->db->query($zrdnum_d)->getResultArray();
            $total_nums_zrd_d = $list_total_zrd_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'cpjhzs'    => $total_nums_zrd,
                'cpjhbt'    => $total_nums_zrd_t,
                'cpjhgjz'   => $total_nums_zrd_k,
                'cpjhnr'    => $total_nums_zrd_d,
            ]);

            //问答
            $wd = 'SELECT SUM(b) AS tjall FROM(' . $counte . ') AS a';
            $list_total_wd = \Phpcmf\Service::M()->db->query($wd)->getResultArray();
            $total_nums_wd = $list_total_wd[0]['tjall'];

            $wdnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_te . ') AS a';
            $list_total_wd_t = \Phpcmf\Service::M()->db->query($wdnum_t)->getResultArray();
            $total_nums_wd_t = $list_total_wd_t[0]['tjall'];

            $wdnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_ke . ') AS a';
            $list_total_wd_k = \Phpcmf\Service::M()->db->query($wdnum_k)->getResultArray();
            $total_nums_wd_k = $list_total_wd_k[0]['tjall'];

            $wdnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_de . ') AS a';
            $list_total_wd_d = \Phpcmf\Service::M()->db->query($wdnum_d)->getResultArray();
            $total_nums_wd_d = $list_total_wd_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'wdzcs'     => $total_nums_wd,
                'wdbtcs'    => $total_nums_wd_t,
                'wdgjccs'   => $total_nums_wd_k,
                'wdnrcs'    => $total_nums_wd_d,
            ]);

            //求车牌号常见问答
            $wda = 'SELECT SUM(b) AS tjall FROM(' . $counte . ' AND catid=22 ) AS a';
            $list_total_wda = \Phpcmf\Service::M()->db->query($wda)->getResultArray();
            $total_nums_wda = $list_total_wda[0]['tjall'];

            $wdanum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_te . ' AND catid=22 ) AS a';
            $list_total_wda_t = \Phpcmf\Service::M()->db->query($wdanum_t)->getResultArray();
            $total_nums_wda_t = $list_total_wda_t[0]['tjall'];

            $wdanum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_ke . ' AND catid=22 ) AS a';
            $list_total_wda_k = \Phpcmf\Service::M()->db->query($wdanum_k)->getResultArray();
            $total_nums_wda_k = $list_total_wda_k[0]['tjall'];

            $wdanum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_de . ' AND catid=22 ) AS a';
            $list_total_wda_d = \Phpcmf\Service::M()->db->query($wdanum_d)->getResultArray();
            $total_nums_wda_d = $list_total_wda_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'qpwdzs'    => $total_nums_wda,
                'qpwdbt'    => $total_nums_wda_t,
                'qpwdgjz'   => $total_nums_wda_k,
                'qpwdnr'    => $total_nums_wda_d,
            ]);

            //京牌转让常见问题
            $wdb = 'SELECT SUM(b) AS tjall FROM(' . $counte . ' AND catid=23 ) AS a';
            $list_total_wdb = \Phpcmf\Service::M()->db->query($wdb)->getResultArray();
            $total_nums_wdb = $list_total_wdb[0]['tjall'];

            $wdbnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_te . ' AND catid=23 ) AS a';
            $list_total_wdb_t = \Phpcmf\Service::M()->db->query($wdbnum_t)->getResultArray();
            $total_nums_wdb_t = $list_total_wdb_t[0]['tjall'];

            $wdbnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_ke . ' AND catid=23 ) AS a';
            $list_total_wdb_k = \Phpcmf\Service::M()->db->query($wdbnum_k)->getResultArray();
            $total_nums_wdb_k = $list_total_wdb_k[0]['tjall'];

            $wdbnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_de . ' AND catid=23 ) AS a';
            $list_total_wdb_d = \Phpcmf\Service::M()->db->query($wdbnum_d)->getResultArray();
            $total_nums_wdb_d = $list_total_wdb_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'zrwdzs'    => $total_nums_wdb,
                'zrwdbt'    => $total_nums_wdb_t,
                'zrwdgjc'   => $total_nums_wdb_k,
                'zrwdnr'    => $total_nums_wdb_d,
            ]);

            //买车用车卖车答疑
            $wdc = 'SELECT SUM(b) AS tjall FROM(' . $counte . ' AND catid=24 ) AS a';
            $list_total_wdc = \Phpcmf\Service::M()->db->query($wdc)->getResultArray();
            $total_nums_wdc = $list_total_wdc[0]['tjall'];

            $wdcnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_te . ' AND catid=24 ) AS a';
            $list_total_wdc_t = \Phpcmf\Service::M()->db->query($wdcnum_t)->getResultArray();
            $total_nums_wdc_t = $list_total_wdc_t[0]['tjall'];

            $wdcnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_ke . ' AND catid=24 ) AS a';
            $list_total_wdc_k = \Phpcmf\Service::M()->db->query($wdcnum_k)->getResultArray();
            $total_nums_wdc_k = $list_total_wdc_k[0]['tjall'];

            $wdcnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_de . ' AND catid=24 ) AS a';
            $list_total_wdc_d = \Phpcmf\Service::M()->db->query($wdcnum_d)->getResultArray();
            $total_nums_wdc_d = $list_total_wdc_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'dyzss'     => $total_nums_wdc,
                'dayibt'    => $total_nums_wdc_t,
                'dygjc'     => $total_nums_wdc_k,
                'dayinr'    => $total_nums_wdc_d,
            ]);

            //资讯
            $zx = 'SELECT SUM(b) AS tjall FROM(' . $countf . ') AS a';
            $list_total_zx = \Phpcmf\Service::M()->db->query($zx)->getResultArray();
            $total_nums_zx = $list_total_zx[0]['tjall'];

            $zxnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tf . ') AS a';
            $list_total_zx_t = \Phpcmf\Service::M()->db->query($zxnum_t)->getResultArray();
            $total_nums_zx_t = $list_total_zx_t[0]['tjall'];

            $zxnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kf . ') AS a';
            $list_total_zx_k = \Phpcmf\Service::M()->db->query($zxnum_k)->getResultArray();
            $total_nums_zx_k = $list_total_zx_k[0]['tjall'];

            $zxnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_df . ') AS a';
            $list_total_zx_d = \Phpcmf\Service::M()->db->query($zxnum_d)->getResultArray();
            $total_nums_zx_d = $list_total_zx_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'bdzxzs'    => $total_nums_zx,
                'bdzxbtcs'  => $total_nums_zx_t,
                'bdgjccs'   => $total_nums_zx_k,
                'bdnrcs'    => $total_nums_zx_d,
            ]);

            //车牌指标
            $zxa = 'SELECT SUM(b) AS tjall FROM(' . $countf . ' AND catid=25 ) AS a';
            $list_total_zxa = \Phpcmf\Service::M()->db->query($zxa)->getResultArray();
            $total_nums_zxa = $list_total_zxa[0]['tjall'];

            $zxanum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tf . ' AND catid=25 ) AS a';
            $list_total_zxa_t = \Phpcmf\Service::M()->db->query($zxanum_t)->getResultArray();
            $total_nums_zxa_t = $list_total_zxa_t[0]['tjall'];

            $zxanum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kf . ' AND catid=25 ) AS a';
            $list_total_zxa_k = \Phpcmf\Service::M()->db->query($zxanum_k)->getResultArray();
            $total_nums_zxa_k = $list_total_zxa_k[0]['tjall'];

            $zxanum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_df . ' AND catid=25 ) AS a';
            $list_total_zxa_d = \Phpcmf\Service::M()->db->query($zxanum_d)->getResultArray();
            $total_nums_zxa_d = $list_total_zxa_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'cpzbzs'    => $total_nums_zxa,
                'cpzbbt'    => $total_nums_zxa_t,
                'cpzbgjc'   => $total_nums_zxa_k,
                'cpzbnr'    => $total_nums_zxa_d,
            ]);

            //汽车资讯
            $zxb = 'SELECT SUM(b) AS tjall FROM(' . $countf . ' AND catid=26 ) AS a';
            $list_total_zxb = \Phpcmf\Service::M()->db->query($zxb)->getResultArray();
            $total_nums_zxb = $list_total_zxb[0]['tjall'];

            $zxbnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tf . ' AND catid=26 ) AS a';
            $list_total_zxb_t = \Phpcmf\Service::M()->db->query($zxbnum_t)->getResultArray();
            $total_nums_zxb_t = $list_total_zxb_t[0]['tjall'];

            $zxbnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kf . ' AND catid=26 ) AS a';
            $list_total_zxb_k = \Phpcmf\Service::M()->db->query($zxbnum_k)->getResultArray();
            $total_nums_zxb_k = $list_total_zxb_k[0]['tjall'];

            $zxbnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_df . ' AND catid=26 ) AS a';
            $list_total_zxb_d = \Phpcmf\Service::M()->db->query($zxbnum_d)->getResultArray();
            $total_nums_zxb_d = $list_total_zxb_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'qczxzs'    => $total_nums_zxb,
                'qczxbt'    => $total_nums_zxb_t,
                'qczxgjc'   => $total_nums_zxb_k,
                'qczxnr'    => $total_nums_zxb_d,
            ]);

            //杂谈热点
            $zxc = 'SELECT SUM(b) AS tjall FROM(' . $countf . ' AND catid=27 ) AS a';
            $list_total_zxc = \Phpcmf\Service::M()->db->query($zxc)->getResultArray();
            $total_nums_zxc = $list_total_zxc[0]['tjall'];

            $zxcnum_t = 'SELECT SUM(b) AS tjall FROM(' . $cou_tf . ' AND catid=27 ) AS a';
            $list_total_zxc_t = \Phpcmf\Service::M()->db->query($zxcnum_t)->getResultArray();
            $total_nums_zxc_t = $list_total_zxc_t[0]['tjall'];

            $zxcnum_k = 'SELECT SUM(b) AS tjall FROM(' . $cou_kf . ' AND catid=27 ) AS a';
            $list_total_zxc_k = \Phpcmf\Service::M()->db->query($zxcnum_k)->getResultArray();
            $total_nums_zxc_k = $list_total_zxc_k[0]['tjall'];

            $zxcnum_d = 'SELECT SUM(b) AS tjall FROM(' . $cou_df . ' AND catid=27 ) AS a';
            $list_total_zxc_d = \Phpcmf\Service::M()->db->query($zxcnum_d)->getResultArray();
            $total_nums_zxc_d = $list_total_zxc_d[0]['tjall'];

            \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where('id',$val['id'])->update([
                'ztrd'      => $total_nums_zxc,
                'ztrdbt'    => $total_nums_zxc_t,
                'ztrdgjc'   => $total_nums_zxc_k,
                'ztrdnr'    => $total_nums_zxc_d,
            ]);

            if($total_update){
                \Phpcmf\Service::M('cache')->sync_cache('tag', 'tag', 1);
            }
        }
        $this->_json(1, $i);
    }
    public function ajaxnum(){
        $list_module = \Phpcmf\Service::L('cache')->get('module-'.SITE_ID.'-content');

        $dbprefix=\Phpcmf\Service::M()->db->DBPrefix; //数据库前缀
        $i = 0;
        $tag = \Phpcmf\Service::L('input')->get('name');
        $lanmu = '';
        $xiangguan = '';
        foreach($list_module as $t) {  //遍历所有模块
            $search_list = 'SELECT sum((LENGTH(`content`) - LENGTH(REPLACE(`content`,"'.$tag.'", ""))) / LENGTH("'.$tag.'")) AS "count" FROM '.$dbprefix.SITE_ID.'_'.$t['dirname'];
            $rt = \Phpcmf\Service::M()->db->query($search_list);
            if ($rt) {
                $rows = $rt->getResultArray();
                $i += (int)$rows[0]['count'];
                if($i > 0){
                    $lanmu .= '<li class="btn btn-secondary btn-sm" style="border: solid 1px #ccc;">'.$t['name'].'</li>';
                }else{
                    $lanmu = '暂无';
                }
            }
        }

        $data = array();
        $data['shuliang'] = $i;
        $data['lanmu'] =$lanmu;
        echo json_encode($data);//输出json数据
    }
    public function ajaxtag(){
        $str = '';
        $dbprefix=\Phpcmf\Service::M()->db->DBPrefix; //数据库前缀
        $id = \Phpcmf\Service::L('input')->get('id');
        $rt = \Phpcmf\Service::M()->db->query("select * from `dr_1_share_category` where id=".$id);
        if ($rt) {
            $row = $rt->getRowArray();
            $tag = \Phpcmf\Service::M()->db->query("select `name` from dr_1_tag");
            if ($tag) {
                $rows = $tag->getResultArray();
                foreach ($rows AS $key=>$val){
                    $search_list = 'SELECT sum((LENGTH(`content`) - LENGTH(REPLACE(`content`,"'.$val['name'].'", ""))) / LENGTH("'.$val['name'].'")) AS "count" FROM '.$dbprefix.SITE_ID.'_'.$row['mid'];
                    $rts = \Phpcmf\Service::M()->db->query($search_list);
                    if ($rts) {
                        $rowss = $rts->getResultArray();
                        if((int)$rowss[0]['count'] > 0){
                            $str .= '|'.$val['name'];
                        }
                    }
                }
            }
            $xiangguan = $str;
        }else{
            $xiangguan = 'ERROR';
        }
        $data = array();

        $data['xiangguan'] =$xiangguan;
        echo json_encode($data);//输出json数据
    }
    // 后台查看列表
    public function index() {

        list($tpl) = $this->_List();


        \Phpcmf\Service::V()->display($tpl);
    }

    // 后台批量添加内容
    public function all_add() {

        if (IS_AJAX_POST) {
            $rt = \Phpcmf\Service::M('Tag', 'tag')->save_all_data($this->pid, $_POST['all']);
            \Phpcmf\Service::M('cache')->sync_cache('tag', 'tag', 1);
            $this->_json($rt['code'], $rt['msg']);
        }

        \Phpcmf\Service::V()->assign([
            'form' => dr_form_hidden(),
            'reply_url' =>\Phpcmf\Service::L('Router')->get_back(\Phpcmf\Service::L('Router')->uri('index')),
        ]);

        \Phpcmf\Service::V()->display('tag_all.html');
    }

    // 后台添加内容
    public function add() {
        list($tpl) = $this->_Post(0);
        \Phpcmf\Service::V()->assign([
            'form' => dr_form_hidden(),
        ]);
        \Phpcmf\Service::V()->display($tpl);exit;
    }


    // 后台修改内容
    public function edit() {
        //内容id
        $tagid =  \Phpcmf\Service::L('Input')->get('id');
        list($tpl) = $this->_Post(intval($tagid));

        //标签名称
        $tag_title = \Phpcmf\Service::M()->table(SITE_ID.'_tag')->where('id',$tagid)->getRow();

        //标签名称
        $tagName = trim($tag_title['name']);



        //相关词
        $xgc = \Phpcmf\Service::M()->db->table(SITE_ID.'_tag')->where(' name LIKE "%'.$tagName.'%"')->get();
        $rowss = $xgc->getResultArray();

        \Phpcmf\Service::V()->assign([
            'form'          => dr_form_hidden(),
            'bqlist'        => $rowss,      //相关词
        ]);
        \Phpcmf\Service::V()->display($tpl);exit;
    }

    // 后台批量保存排序值
    public function order_edit() {
        $this->_Display_Order(
            intval(\Phpcmf\Service::L('Input')->get('id')),
            intval(\Phpcmf\Service::L('Input')->get('value')),
            function ($r) {
                \Phpcmf\Service::M('cache')->sync_cache('tag', 'tag', 1);
            }
        );
    }

    // 后台删除内容
    public function del() {
        $this->_Del(
            \Phpcmf\Service::L('Input')->get_post_ids(),
            null,
            function ($r) {
                \Phpcmf\Service::M('cache')->sync_cache('tag', 'tag', 1);
            },
            \Phpcmf\Service::M()->dbprefix($this->init['table'])
        );
    }

    // ===========================

    /**
     * 保存内容
     * $id      内容id,新增为0
     * $data    提交内容数组,留空为自动获取
     * $func    格式化提交的数据
     * */
    protected function _Save($id = 0, $data = [], $old = [], $func = null, $func2 = null) {

        return parent::_Save($id, $data, $old,
            function ($id, $data, $old) {
                // 提交之前的判断
                $post = \Phpcmf\Service::L('Input')->post('data');
//                if (\Phpcmf\Service::M('Tag', 'tag')->check_code($id, $post['code'])) {
//                    return dr_return_data(0, dr_lang('别名已经存在'));
//                } elseif (\Phpcmf\Service::M('Tag', 'tag')->check_name($id, $post['name'])) {
//                    return dr_return_data(0, dr_lang('tag名称已经存在'));
//                }
                if (\Phpcmf\Service::M('Tag', 'tag')->check_name($id, $post['name'])) {
                    return dr_return_data(0, dr_lang('tag名称已经存在'));
                }
                $data[1]['pid'] = $old ? $old['pid'] : $this->pid;
                !$old && $data[1]['childids'] = ''; // 初始化字段
                $data[1]['code'] = $post['code'];
                $data[1]['hits'] = intval($post['hits']);
                !$data[1]['content'] && $data[1]['content'] = '';
                return dr_return_data(1, 'ok', $data);
            },
            function ($id, $data, $old) {
                // 提交之后
                $data[1]['pcode'] = \Phpcmf\Service::M('Tag', 'tag')->get_pcode($data[1]);
                // 更新
                \Phpcmf\Service::M('Tag', 'tag')->save_data($id, array(
                    'pcode' => $data[1]['pcode'],
                ));
                if ($data[1]['pid']) {
                    // 标记存在子菜单
                    \Phpcmf\Service::M()->table(SITE_ID.'_tag')->update($data[1]['pid'], array(
                        'childids' => 1,
                    ));
                }

                \Phpcmf\Service::M('cache')->sync_cache('tag', 'tag', 1);
                return $data;
            }
        );
    }

    // 后台批量移动栏目
    public function move_edit() {

        $ids = \Phpcmf\Service::L('input')->get_post_ids();
        if (!$ids) {
            $this->_json(0, dr_lang('所选tag不存在'));
        }
        // 批量更换栏目
        \Phpcmf\Service::M()->db->table($this->init['table'])->whereIn('id', $ids)->update(['type' => $_POST['type']]);

        // 自动更新缓存
        \Phpcmf\Service::M('cache')->sync_cache();
        $this->_json(1, dr_lang('操作成功'));
    }
    
}
