<?php namespace Phpcmf\Controllers\Admin;

class Column extends \Phpcmf\Table
{

	public function index() {

	    //重要提醒
        $tix = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('txzcs > 0')->get();
        $tixs = $tix->getResultArray();

        //求车牌号注意事项
        $tixa = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('qpzyzs > 0')->get();
        $tixas = $tixa->getResultArray();

        //京牌转让注意事项
        $tixb = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('zrzyzs > 0')->get();
        $tixbs = $tixb->getResultArray();

        //买车用车卖车提醒
        $tixc = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('myctxzs > 0')->get();
        $tixcs = $tixc->getResultArray();


        //科普指南
        $zhin = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('znzcs > 0')->get();
        $zhins = $zhin->getResultArray();

        //北京车牌办理指南
        $zhina = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('blznzs > 0')->get();
        $zhinas = $zhina->getResultArray();

        //北京车牌转让技巧
        $zhinb = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('zrjqzs > 0')->get();
        $zhinbs = $zhinb->getResultArray();

        //买车用车卖车技巧
        $zhinc = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('mcjqzs > 0')->get();
        $zhincs = $zhinc->getResultArray();

        //我求车牌号
        $qcp = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('qcpzcs > 0')->get();
        $qcps = $qcp->getResultArray();

        //小汽车指标出租
        $qcpa = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('zbczzs > 0')->get();
        $qcpas = $qcpa->getResultArray();

        //新能源车牌出租
        $qcpb = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('cpczzs > 0')->get();
        $qcpbs = $qcpb->getResultArray();

        //北京车牌出售
        $qcpc = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('cpcszs > 0')->get();
        $qcpcs = $qcpc->getResultArray();

        //靓号车牌转让
        $qcpd = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('cpzrzs > 0')->get();
        $qcpds = $qcpd->getResultArray();

        //我有牌转让
        $zhuanr = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('zrzcs > 0')->get();
        $zhuanrs = $zhuanr->getResultArray();

        //求租北京车牌
        $zhuanra = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('qzcpzs > 0')->get();
        $zhuanras = $zhuanra->getResultArray();

        //求租新能源车牌
        $zhuanrb = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('xnyzs > 0')->get();
        $zhuanrbs = $zhuanrb->getResultArray();

        //求购京牌指标
        $zhuanrc = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('jpzbzs > 0')->get();
        $zhuanrcs = $zhuanrc->getResultArray();

        //求北京车牌靓号
        $zhuanrd = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('cpjhzs > 0')->get();
        $zhuanrds = $zhuanrd->getResultArray();

        //常见问答
        $wd = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('wdzcs > 0')->get();
        $wds = $wd->getResultArray();

        //求车牌号常见问答
        $wda = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('qpwdzs > 0')->get();
        $wdas = $wda->getResultArray();

        //京牌转让常见问题
        $wdb = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('zrwdzs > 0')->get();
        $wdbs = $wdb->getResultArray();

        //买车用车卖车答疑
        $wdc = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('dyzss > 0')->get();
        $wdcs = $wdc->getResultArray();

        //宝典资讯
        $zix = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('bdzxzs > 0')->get();
        $zixs = $zix->getResultArray();

        //车牌指标
        $zixa = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('cpzbzs > 0')->get();
        $zixas = $zixa->getResultArray();

        //汽车资讯
        $zixb = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('qczxzs > 0')->get();
        $zixbs = $zixb->getResultArray();

        //杂谈热点
        $zixc = \Phpcmf\Service::M()->db->table('dr_1_tag')->where('ztrd > 0')->get();
        $zixcs = $zixc->getResultArray();


        \Phpcmf\Service::V()->assign([
            'tixs'    => $tixs,
            'tixa'    => $tixas,
            'tixb'    => $tixbs,
            'tixc'    => $tixcs,
            'zhin'    => $zhins,
            'zhina'   => $zhinas,
            'zhinb'   => $zhinbs,
            'zhinc'   => $zhincs,
            'qcps'    => $qcps,
            'qcpas'   => $qcpas,
            'qcpbs'   => $qcpbs,
            'qcpcs'   => $qcpcs,
            'qcpds'   => $qcpds,
            'zhuanrs'   => $zhuanrs,
            'zhuanras'   => $zhuanras,
            'zhuanrbs'   => $zhuanrbs,
            'zhuanrcs'   => $zhuanrcs,
            'zhuanrds'   => $zhuanrds,
            'wds'   => $wds,
            'wdas'   => $wdas,
            'wdbs'   => $wdbs,
            'wdcs'   => $wdcs,
            'zixs'   => $zixs,
            'zixas'   => $zixas,
            'zixbs'   => $zixbs,
            'zixcs'   => $zixcs,

        ]);

        \Phpcmf\Service::V()->display('column.html');

	}




}
